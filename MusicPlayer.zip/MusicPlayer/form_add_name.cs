﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03
{
    public partial class form_add_name : Form
    {
        public int idbaihat { get; set; }
        public form_add_name()
        {
            InitializeComponent();
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string tenplaylist = txt_name.Text;
            if (playlist.CheckTrung(tenplaylist))
                MessageBox.Show("Tên playlist đã tồn tại!");
            else
            {
                playlist.AddOne(tenplaylist, idbaihat);
                MessageBox.Show("Thêm thành công vào " + tenplaylist);
                this.Close();
            }
        }
    }
}
