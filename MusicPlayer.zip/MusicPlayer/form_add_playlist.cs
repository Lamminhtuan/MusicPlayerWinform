﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03
{
    public partial class form_add_playlist : Form
    {
        public int idbaihat { get; set; }
        public form_add_playlist()
        {
            InitializeComponent();
        }

        private void form_list_Load(object sender, EventArgs e)
        {

            DataTable dt = playlist.data.DefaultView.ToTable(true, "NamePlaylist");
            dtgrid.DataSource = dt;
        }

        private void dtgrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string tenplaylist = dtgrid.SelectedRows[0].Cells["NamePlaylist"].Value.ToString();

            if (!playlist.CheckTrungPlaylist(tenplaylist, idbaihat))
            {
                playlist.AddOne(tenplaylist, idbaihat);
                MessageBox.Show("Thêm thành công vào " + tenplaylist);


            }
            else
                MessageBox.Show("Playlist đã tồn tại bài hát!");
            this.Close();

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            form_add_name fn = new form_add_name();
            fn.idbaihat = idbaihat;
            fn.ShowDialog();
            this.Close();
        }
    }
}
