﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03
{
    public partial class form_history : Form
    {
        public form_history()
        {
            InitializeComponent();
        }

        private void form_history_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = history.data;
            if (!dt.Columns.Contains("Hinh"))
                dt.Columns.Add("Hinh", Type.GetType("System.Byte[]"));
            
            foreach (DataRow dr in dt.Rows)
            {
                dr["Hinh"] = File.ReadAllBytes(dr["ImagePath"].ToString());
            }
            dtgrid.DataSource = dt;
        }

        private void dtgrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string musicpath = dtgrid.SelectedRows[0].Cells["MusicPath"].Value.ToString();
            string imagepath = dtgrid.SelectedRows[0].Cells["ImagePath"].Value.ToString();
            string casi = dtgrid.SelectedRows[0].Cells["Singer"].Value.ToString();
            string tenbaihat = dtgrid.SelectedRows[0].Cells["SongName"].Value.ToString();
            string tacgia = dtgrid.SelectedRows[0].Cells["Author"].Value.ToString();
            double star = Convert.ToDouble(dtgrid.SelectedRows[0].Cells["Star"].Value.ToString());
            int id = Convert.ToInt32(dtgrid.SelectedRows[0].Cells["ID"].Value.ToString());
            string theloai = dtgrid.SelectedRows[0].Cells["Kind"].Value.ToString();
            string quocgia = dtgrid.SelectedRows[0].Cells["Nation"].Value.ToString();
            string loibaihat = dtgrid.SelectedRows[0].Cells["Lyrics"].Value.ToString();
            form_play form_Play = new form_play();
            songs.AddOne(id);

            int luotnghe = songs.GetView(id);
            string time = DateTime.Now.ToString();
            history.Add(id, imagepath, musicpath, tenbaihat, tacgia, casi, quocgia, theloai, luotnghe, loibaihat, star, time);
            form_Play.musicpath = musicpath;
            form_Play.imagepath = imagepath;
            form_Play.tenbaihat = tenbaihat;
            form_Play.casi = casi;
            form_Play.loibaihat = loibaihat;
            form_Play.theloai = theloai;
            form_Play.quocgia = quocgia;
            form_Play.luotnghe = luotnghe;
            form_Play.ID = id;
            form_Play.star = star;
            form_Play.tacgia = tacgia;
            form_Play.ShowDialog();
            DataTable dt = new DataTable();
            dt = history.data;
            if (!dt.Columns.Contains("Hinh"))
                dt.Columns.Add("Hinh", Type.GetType("System.Byte[]"));

            foreach (DataRow dr in dt.Rows)
            {
                dr["Hinh"] = File.ReadAllBytes(dr["ImagePath"].ToString());
            }
            dtgrid.DataSource = dt;

        }
    }
}
