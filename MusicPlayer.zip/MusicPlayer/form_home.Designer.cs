﻿namespace TH03
{
    partial class form_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_home));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_search = new System.Windows.Forms.Button();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.btn_history = new System.Windows.Forms.Button();
            this.btn_playlist = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_love = new System.Windows.Forms.Button();
            this.dtgrid = new System.Windows.Forms.DataGridView();
            this.Hinh = new System.Windows.Forms.DataGridViewImageColumn();
            this.SongName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.singer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Author = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lyrics = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ImagePath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MusicPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Star = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.View = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Kind = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.cb_sortdg = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.cb_sortnghe = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cb_theloai = new System.Windows.Forms.ComboBox();
            this.btn_xoaloc = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_loc = new System.Windows.Forms.Button();
            this.cb_quocgia = new System.Windows.Forms.ComboBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.cb_tacgia = new System.Windows.Forms.ComboBox();
            this.cb_casi = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrid)).BeginInit();
            this.panel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(92)))), ((int)(((byte)(227)))));
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.btn_search);
            this.panel1.Controls.Add(this.txt_search);
            this.panel1.Controls.Add(this.btn_history);
            this.panel1.Controls.Add(this.btn_playlist);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.btn_love);
            this.panel1.Location = new System.Drawing.Point(-3, -1);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1209, 66);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox5.Location = new System.Drawing.Point(0, 0);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(227, 66);
            this.pictureBox5.TabIndex = 3;
            this.pictureBox5.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(0, 63);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(269, 479);
            this.panel2.TabIndex = 2;
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(14)))), ((int)(((byte)(139)))));
            this.btn_search.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_search.BackgroundImage")));
            this.btn_search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_search.FlatAppearance.BorderSize = 0;
            this.btn_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search.Location = new System.Drawing.Point(704, 9);
            this.btn_search.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(73, 52);
            this.btn_search.TabIndex = 2;
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // txt_search
            // 
            this.txt_search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.ForeColor = System.Drawing.Color.LightGray;
            this.txt_search.Location = new System.Drawing.Point(372, 9);
            this.txt_search.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_search.Multiline = true;
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(339, 51);
            this.txt_search.TabIndex = 1;
            this.txt_search.Text = "Tìm kiếm tên bài hát";
            this.txt_search.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txt_search_MouseClick);
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            this.txt_search.MouseLeave += new System.EventHandler(this.txt_search_MouseLeave);
            // 
            // btn_history
            // 
            this.btn_history.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(14)))), ((int)(((byte)(139)))));
            this.btn_history.FlatAppearance.BorderSize = 0;
            this.btn_history.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_history.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_history.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_history.Image = ((System.Drawing.Image)(resources.GetObject("btn_history.Image")));
            this.btn_history.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_history.Location = new System.Drawing.Point(1063, 10);
            this.btn_history.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_history.Name = "btn_history";
            this.btn_history.Size = new System.Drawing.Size(132, 52);
            this.btn_history.TabIndex = 0;
            this.btn_history.Text = "Lịch sử nghe";
            this.btn_history.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_history.UseVisualStyleBackColor = false;
            this.btn_history.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_playlist
            // 
            this.btn_playlist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(14)))), ((int)(((byte)(139)))));
            this.btn_playlist.FlatAppearance.BorderSize = 0;
            this.btn_playlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_playlist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_playlist.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_playlist.Image = ((System.Drawing.Image)(resources.GetObject("btn_playlist.Image")));
            this.btn_playlist.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_playlist.Location = new System.Drawing.Point(925, 10);
            this.btn_playlist.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_playlist.Name = "btn_playlist";
            this.btn_playlist.Size = new System.Drawing.Size(132, 52);
            this.btn_playlist.TabIndex = 0;
            this.btn_playlist.Text = "Playlist\r\ncủa tôi\r\n\r\n";
            this.btn_playlist.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_playlist.UseVisualStyleBackColor = false;
            this.btn_playlist.Click += new System.EventHandler(this.btn_playlist_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(14)))), ((int)(((byte)(139)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(225, 9);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(141, 52);
            this.button2.TabIndex = 0;
            this.button2.Text = "TOP 10\r\nlượt nghe";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_love
            // 
            this.btn_love.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(14)))), ((int)(((byte)(139)))));
            this.btn_love.FlatAppearance.BorderSize = 0;
            this.btn_love.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_love.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_love.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btn_love.Image = ((System.Drawing.Image)(resources.GetObject("btn_love.Image")));
            this.btn_love.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_love.Location = new System.Drawing.Point(783, 10);
            this.btn_love.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_love.Name = "btn_love";
            this.btn_love.Size = new System.Drawing.Size(136, 52);
            this.btn_love.TabIndex = 0;
            this.btn_love.Text = "Playlist\r\nyêu thích\r\n";
            this.btn_love.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_love.UseVisualStyleBackColor = false;
            this.btn_love.Click += new System.EventHandler(this.btn_love_Click);
            // 
            // dtgrid
            // 
            this.dtgrid.AllowUserToAddRows = false;
            this.dtgrid.AllowUserToDeleteRows = false;
            this.dtgrid.AllowUserToOrderColumns = true;
            this.dtgrid.AllowUserToResizeColumns = false;
            this.dtgrid.AllowUserToResizeRows = false;
            this.dtgrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(241)))), ((int)(((byte)(255)))));
            this.dtgrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgrid.ColumnHeadersVisible = false;
            this.dtgrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Hinh,
            this.SongName,
            this.singer,
            this.Author,
            this.Lyrics,
            this.ImagePath,
            this.MusicPath,
            this.ID,
            this.Star,
            this.View,
            this.Nation,
            this.Kind});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(241)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Magenta;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgrid.DefaultCellStyle = dataGridViewCellStyle1;
            this.dtgrid.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtgrid.Location = new System.Drawing.Point(272, 71);
            this.dtgrid.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgrid.Name = "dtgrid";
            this.dtgrid.ReadOnly = true;
            this.dtgrid.RowHeadersVisible = false;
            this.dtgrid.RowHeadersWidth = 51;
            this.dtgrid.RowTemplate.Height = 50;
            this.dtgrid.RowTemplate.ReadOnly = true;
            this.dtgrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgrid.Size = new System.Drawing.Size(935, 527);
            this.dtgrid.TabIndex = 1;
            this.dtgrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgrid_CellContentClick);
            this.dtgrid.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgrid_CellContentDoubleClick);
            this.dtgrid.SelectionChanged += new System.EventHandler(this.dtgrid_SelectionChanged);
            // 
            // Hinh
            // 
            this.Hinh.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Hinh.DataPropertyName = "Hinh";
            this.Hinh.FillWeight = 129.0553F;
            this.Hinh.HeaderText = "Hinh";
            this.Hinh.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.Hinh.MinimumWidth = 6;
            this.Hinh.Name = "Hinh";
            this.Hinh.ReadOnly = true;
            this.Hinh.Width = 6;
            // 
            // SongName
            // 
            this.SongName.DataPropertyName = "SongName";
            this.SongName.HeaderText = "Song Name";
            this.SongName.MinimumWidth = 6;
            this.SongName.Name = "SongName";
            this.SongName.ReadOnly = true;
            // 
            // singer
            // 
            this.singer.DataPropertyName = "Singer";
            this.singer.HeaderText = "Singer";
            this.singer.MinimumWidth = 6;
            this.singer.Name = "singer";
            this.singer.ReadOnly = true;
            // 
            // Author
            // 
            this.Author.DataPropertyName = "Author";
            this.Author.HeaderText = "Column1";
            this.Author.MinimumWidth = 6;
            this.Author.Name = "Author";
            this.Author.ReadOnly = true;
            this.Author.Visible = false;
            // 
            // Lyrics
            // 
            this.Lyrics.DataPropertyName = "Lyrics";
            this.Lyrics.HeaderText = "Column1";
            this.Lyrics.MinimumWidth = 6;
            this.Lyrics.Name = "Lyrics";
            this.Lyrics.ReadOnly = true;
            this.Lyrics.Visible = false;
            // 
            // ImagePath
            // 
            this.ImagePath.DataPropertyName = "ImagePath";
            this.ImagePath.HeaderText = "Column1";
            this.ImagePath.MinimumWidth = 6;
            this.ImagePath.Name = "ImagePath";
            this.ImagePath.ReadOnly = true;
            this.ImagePath.Visible = false;
            // 
            // MusicPath
            // 
            this.MusicPath.DataPropertyName = "MusicPath";
            this.MusicPath.HeaderText = "Column1";
            this.MusicPath.MinimumWidth = 6;
            this.MusicPath.Name = "MusicPath";
            this.MusicPath.ReadOnly = true;
            this.MusicPath.Visible = false;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "Column1";
            this.ID.MinimumWidth = 6;
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            // 
            // Star
            // 
            this.Star.DataPropertyName = "Star";
            this.Star.HeaderText = "Column1";
            this.Star.MinimumWidth = 6;
            this.Star.Name = "Star";
            this.Star.ReadOnly = true;
            this.Star.Visible = false;
            // 
            // View
            // 
            this.View.DataPropertyName = "View";
            this.View.HeaderText = "Column1";
            this.View.MinimumWidth = 6;
            this.View.Name = "View";
            this.View.ReadOnly = true;
            this.View.Visible = false;
            // 
            // Nation
            // 
            this.Nation.DataPropertyName = "Nation";
            this.Nation.HeaderText = "Column1";
            this.Nation.MinimumWidth = 6;
            this.Nation.Name = "Nation";
            this.Nation.ReadOnly = true;
            this.Nation.Visible = false;
            // 
            // Kind
            // 
            this.Kind.DataPropertyName = "Kind";
            this.Kind.HeaderText = "Column1";
            this.Kind.MinimumWidth = 6;
            this.Kind.Name = "Kind";
            this.Kind.ReadOnly = true;
            this.Kind.Visible = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Controls.Add(this.groupBox2);
            this.panel3.Location = new System.Drawing.Point(1, 65);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(264, 533);
            this.panel3.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.cb_sortdg);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.cb_sortnghe);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Location = new System.Drawing.Point(15, 320);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(237, 198);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sắp xếp";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(53, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 24);
            this.label2.TabIndex = 8;
            this.label2.Text = "THEO ĐÁNH GIÁ";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox6.Location = new System.Drawing.Point(5, 110);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(39, 30);
            this.pictureBox6.TabIndex = 7;
            this.pictureBox6.TabStop = false;
            // 
            // cb_sortdg
            // 
            this.cb_sortdg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.cb_sortdg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_sortdg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_sortdg.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.cb_sortdg.FormattingEnabled = true;
            this.cb_sortdg.Items.AddRange(new object[] {
            "Tăng dần",
            "Giảm dần"});
            this.cb_sortdg.Location = new System.Drawing.Point(5, 144);
            this.cb_sortdg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cb_sortdg.Name = "cb_sortdg";
            this.cb_sortdg.Size = new System.Drawing.Size(221, 33);
            this.cb_sortdg.TabIndex = 6;
            this.cb_sortdg.Text = "Sắp xếp";
            this.cb_sortdg.SelectedIndexChanged += new System.EventHandler(this.cb_sortdg_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "THEO LƯỢT NGHE";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox4.Location = new System.Drawing.Point(7, 27);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(39, 30);
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // cb_sortnghe
            // 
            this.cb_sortnghe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.cb_sortnghe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_sortnghe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_sortnghe.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.cb_sortnghe.FormattingEnabled = true;
            this.cb_sortnghe.Items.AddRange(new object[] {
            "Tăng dần",
            "Giảm dần"});
            this.cb_sortnghe.Location = new System.Drawing.Point(7, 62);
            this.cb_sortnghe.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cb_sortnghe.Name = "cb_sortnghe";
            this.cb_sortnghe.Size = new System.Drawing.Size(221, 33);
            this.cb_sortnghe.TabIndex = 3;
            this.cb_sortnghe.Text = "Sắp xếp";
            this.cb_sortnghe.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cb_theloai);
            this.groupBox2.Controls.Add(this.btn_xoaloc);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.btn_loc);
            this.groupBox2.Controls.Add(this.cb_quocgia);
            this.groupBox2.Controls.Add(this.pictureBox7);
            this.groupBox2.Controls.Add(this.pictureBox3);
            this.groupBox2.Controls.Add(this.pictureBox2);
            this.groupBox2.Controls.Add(this.cb_tacgia);
            this.groupBox2.Controls.Add(this.cb_casi);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(11, 6);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(237, 309);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bộ lọc";
            // 
            // cb_theloai
            // 
            this.cb_theloai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.cb_theloai.CausesValidation = false;
            this.cb_theloai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_theloai.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_theloai.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.cb_theloai.FormattingEnabled = true;
            this.cb_theloai.Location = new System.Drawing.Point(56, 33);
            this.cb_theloai.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cb_theloai.Name = "cb_theloai";
            this.cb_theloai.Size = new System.Drawing.Size(183, 33);
            this.cb_theloai.TabIndex = 0;
            this.cb_theloai.Text = "Thể loại";
            // 
            // btn_xoaloc
            // 
            this.btn_xoaloc.AutoSize = true;
            this.btn_xoaloc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.btn_xoaloc.FlatAppearance.BorderSize = 0;
            this.btn_xoaloc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_xoaloc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_xoaloc.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_xoaloc.Image = ((System.Drawing.Image)(resources.GetObject("btn_xoaloc.Image")));
            this.btn_xoaloc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_xoaloc.Location = new System.Drawing.Point(40, 253);
            this.btn_xoaloc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_xoaloc.Name = "btn_xoaloc";
            this.btn_xoaloc.Size = new System.Drawing.Size(152, 50);
            this.btn_xoaloc.TabIndex = 2;
            this.btn_xoaloc.Text = "Xóa lọc";
            this.btn_xoaloc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_xoaloc.UseVisualStyleBackColor = false;
            this.btn_xoaloc.Click += new System.EventHandler(this.btn_xoaloc_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(4, 33);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(45, 33);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // btn_loc
            // 
            this.btn_loc.AutoSize = true;
            this.btn_loc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.btn_loc.FlatAppearance.BorderSize = 0;
            this.btn_loc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_loc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_loc.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_loc.Image = ((System.Drawing.Image)(resources.GetObject("btn_loc.Image")));
            this.btn_loc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_loc.Location = new System.Drawing.Point(40, 199);
            this.btn_loc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_loc.Name = "btn_loc";
            this.btn_loc.Size = new System.Drawing.Size(152, 50);
            this.btn_loc.TabIndex = 2;
            this.btn_loc.Text = "Lọc";
            this.btn_loc.UseVisualStyleBackColor = false;
            this.btn_loc.Click += new System.EventHandler(this.btn_loc_Click);
            // 
            // cb_quocgia
            // 
            this.cb_quocgia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.cb_quocgia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_quocgia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_quocgia.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.cb_quocgia.FormattingEnabled = true;
            this.cb_quocgia.Location = new System.Drawing.Point(56, 71);
            this.cb_quocgia.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cb_quocgia.Name = "cb_quocgia";
            this.cb_quocgia.Size = new System.Drawing.Size(183, 33);
            this.cb_quocgia.TabIndex = 0;
            this.cb_quocgia.Text = "Quốc gia";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox7.Location = new System.Drawing.Point(5, 150);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(45, 33);
            this.pictureBox7.TabIndex = 1;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(4, 111);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(45, 33);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(4, 71);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(45, 33);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // cb_tacgia
            // 
            this.cb_tacgia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.cb_tacgia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_tacgia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_tacgia.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.cb_tacgia.FormattingEnabled = true;
            this.cb_tacgia.Location = new System.Drawing.Point(57, 150);
            this.cb_tacgia.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cb_tacgia.Name = "cb_tacgia";
            this.cb_tacgia.Size = new System.Drawing.Size(183, 33);
            this.cb_tacgia.TabIndex = 0;
            this.cb_tacgia.Text = "Tác giả";
            // 
            // cb_casi
            // 
            this.cb_casi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.cb_casi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_casi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_casi.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.cb_casi.FormattingEnabled = true;
            this.cb_casi.Location = new System.Drawing.Point(56, 111);
            this.cb_casi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cb_casi.Name = "cb_casi";
            this.cb_casi.Size = new System.Drawing.Size(183, 33);
            this.cb_casi.TabIndex = 0;
            this.cb_casi.Text = "Ca sĩ";
            // 
            // form_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1207, 597);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.dtgrid);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.Name = "form_home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nghe nhạc";
            this.Load += new System.EventHandler(this.form_home_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrid)).EndInit();
            this.panel3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.DataGridView dtgrid;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox cb_theloai;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ComboBox cb_casi;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ComboBox cb_quocgia;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_xoaloc;
        private System.Windows.Forms.Button btn_loc;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.ComboBox cb_sortnghe;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.ComboBox cb_sortdg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewImageColumn Hinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn SongName;
        private System.Windows.Forms.DataGridViewTextBoxColumn singer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Author;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lyrics;
        private System.Windows.Forms.DataGridViewTextBoxColumn ImagePath;
        private System.Windows.Forms.DataGridViewTextBoxColumn MusicPath;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Star;
        private System.Windows.Forms.DataGridViewTextBoxColumn View;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nation;
        private System.Windows.Forms.DataGridViewTextBoxColumn Kind;
        private System.Windows.Forms.Button btn_love;
        private System.Windows.Forms.Button btn_playlist;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_history;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.ComboBox cb_tacgia;
    }
}

