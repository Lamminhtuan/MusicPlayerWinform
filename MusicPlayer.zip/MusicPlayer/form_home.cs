﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03
{
    public partial class form_home : Form
    {
        DataTable data = new DataTable();

        public form_home()
        {
            InitializeComponent();
        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void form_home_Load(object sender, EventArgs e)
        {
            songs.KhoiTao();
            reviews.KhoiTao();
            history.KhoiTao();
            data = songs.data;

            playlist.KhoiTao();
            DataTable theloai = data.DefaultView.ToTable(true, "Kind");
            DataTable quocgia = data.DefaultView.ToTable(true, "Nation");
            DataTable casi = data.DefaultView.ToTable(true, "Singer");
            DataTable tacgia = data.DefaultView.ToTable(true, "Author");
            foreach (DataRow dr in theloai.Rows)
            {
                cb_theloai.Items.Add(dr["Kind"].ToString());
            }
            foreach (DataRow dr in quocgia.Rows)
            {
                cb_quocgia.Items.Add(dr["Nation"].ToString());
            }
            foreach (DataRow dr in casi.Rows)
            {
                cb_casi.Items.Add(dr["Singer"].ToString());
            }
            foreach(DataRow dr in tacgia.Rows)
            {
                cb_tacgia.Items.Add(dr["Author"].ToString());
            }
            data.Columns.Add("Hinh", Type.GetType("System.Byte[]"));
            foreach (DataRow dr in data.Rows)
            {
                dr["Hinh"] = File.ReadAllBytes(dr["ImagePath"].ToString());
            }
            dtgrid.DataSource = data;
        }

        private void dtgrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            string musicpath = dtgrid.SelectedRows[0].Cells["MusicPath"].Value.ToString();
            string imagepath = dtgrid.SelectedRows[0].Cells["ImagePath"].Value.ToString();
            string casi = dtgrid.SelectedRows[0].Cells["Singer"].Value.ToString();
            string tenbaihat = dtgrid.SelectedRows[0].Cells["SongName"].Value.ToString();
            string tacgia = dtgrid.SelectedRows[0].Cells["Author"].Value.ToString();
            double star = Convert.ToDouble(dtgrid.SelectedRows[0].Cells["Star"].Value.ToString());
            int id = Convert.ToInt32(dtgrid.SelectedRows[0].Cells["ID"].Value.ToString());
            string theloai = dtgrid.SelectedRows[0].Cells["Kind"].Value.ToString();
            string quocgia = dtgrid.SelectedRows[0].Cells["Nation"].Value.ToString();
            string loibaihat = dtgrid.SelectedRows[0].Cells["Lyrics"].Value.ToString();
            form_play form_Play = new form_play();
            songs.AddOne(id);
            
            int luotnghe = songs.GetView(id);
            string time = DateTime.Now.ToString();
            history.Add(id, imagepath, musicpath, tenbaihat, tacgia, casi, quocgia, theloai, luotnghe, loibaihat, star, time);
            form_Play.musicpath = musicpath;
            form_Play.imagepath = imagepath;
            form_Play.tenbaihat = tenbaihat;
            form_Play.casi = casi;
            form_Play.loibaihat = loibaihat;
            form_Play.theloai = theloai;
            form_Play.quocgia = quocgia;
            form_Play.luotnghe = luotnghe;
            form_Play.ID = id;
            form_Play.star = star;
            form_Play.tacgia = tacgia;
            form_Play.ShowDialog();
        }

        private void dtgrid_SelectionChanged(object sender, EventArgs e)
        {
           
        }

        private void txt_search_MouseClick(object sender, MouseEventArgs e)
        {
            txt_search.Text = "";
            txt_search.ForeColor = Color.Black;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string search = txt_search.Text;
            if (search =="")
            {
                data = songs.data;
                dtgrid.DataSource = data;
            }
            else if (search=="Tìm kiếm tên bài hát")
            {
                MessageBox.Show("Vui lòng nhập tên bài hát cần tìm!");
            }
            else
            {
                DataTable temp = songs.Search(search);
                if (temp.Rows.Count > 0)
                    dtgrid.DataSource = temp;
                else
                    MessageBox.Show("Không tìm thấy bài hát nào!");
            }
        }

        private void txt_search_MouseLeave(object sender, EventArgs e)
        {
          
        }

        private void dtgrid_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void btn_loc_Click(object sender, EventArgs e)
        {
            string theloai = "";
            string quocgia = "";
            string casi = "";
            string tacgia = "";
            if (cb_theloai.Text != "Thể loại"){
                theloai = cb_theloai.Text;
            }
            if (cb_quocgia.Text != "Quốc gia")
            {
                quocgia = cb_quocgia.Text;
            }
            if (cb_casi.Text != "Ca sĩ")
            {
                casi = cb_casi.Text;
            }
            if (cb_tacgia.Text != "Tác giả")
            {
                tacgia = cb_tacgia.Text;
            }
            DataTable temp = songs.Filter(theloai, quocgia, casi, tacgia);
            if (temp.Rows.Count > 0)
                dtgrid.DataSource = temp;
            else
                MessageBox.Show("Không tìm thấy bài hát nào!");

        }

        private void btn_xoaloc_Click(object sender, EventArgs e)
        {
            data = songs.data;
            dtgrid.DataSource = data;
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_sortnghe.Text == "Tăng dần")
                dtgrid.Sort(dtgrid.Columns["View"], ListSortDirection.Ascending);
            else if (cb_sortnghe.Text == "Giảm dần")
                dtgrid.Sort(dtgrid.Columns["View"], ListSortDirection.Descending);
        }

        private void cb_sortdg_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_sortdg.Text == "Tăng dần")
                dtgrid.Sort(dtgrid.Columns["Star"], ListSortDirection.Ascending);
            else if (cb_sortdg.Text == "Giảm dần")
                dtgrid.Sort(dtgrid.Columns["Star"], ListSortDirection.Descending);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_love_Click(object sender, EventArgs e)
        {
            if (!playlist.CheckYeuThichRong())
            {
                form_playlist form_Playlist = new form_playlist();
                form_Playlist.formname = "Playlist yêu thích";
                form_Playlist.ShowDialog();
            }
            else
                MessageBox.Show("Chưa có bài hát yêu thích nào!");
        }

        private void btn_playlist_Click(object sender, EventArgs e)
        {
            form_list form_List = new form_list();
            form_List.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (history.data.Rows.Count == 0)
                MessageBox.Show("Bạn chưa nghe bài hát nào!");
            else
            {
                form_history form_history = new form_history();
                form_history.ShowDialog();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            form_rank fr = new form_rank();
            fr.ShowDialog();
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {

        }
    }
}


