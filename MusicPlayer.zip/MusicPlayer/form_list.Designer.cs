﻿namespace TH03
{
    partial class form_list
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_list));
            this.dtgrid = new System.Windows.Forms.DataGridView();
            this.NamePlaylist = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDBaihat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrid)).BeginInit();
            this.SuspendLayout();
            // 
            // dtgrid
            // 
            this.dtgrid.AllowUserToAddRows = false;
            this.dtgrid.AllowUserToDeleteRows = false;
            this.dtgrid.AllowUserToResizeColumns = false;
            this.dtgrid.AllowUserToResizeRows = false;
            this.dtgrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.dtgrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
            this.dtgrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgrid.ColumnHeadersVisible = false;
            this.dtgrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NamePlaylist,
            this.IDBaihat});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.MediumSlateBlue;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgrid.DefaultCellStyle = dataGridViewCellStyle1;
            this.dtgrid.Location = new System.Drawing.Point(12, 12);
            this.dtgrid.Name = "dtgrid";
            this.dtgrid.ReadOnly = true;
            this.dtgrid.RowHeadersVisible = false;
            this.dtgrid.RowHeadersWidth = 51;
            this.dtgrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgrid.Size = new System.Drawing.Size(463, 321);
            this.dtgrid.TabIndex = 0;
            this.dtgrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgrid_CellContentClick);
            // 
            // NamePlaylist
            // 
            this.NamePlaylist.DataPropertyName = "NamePlaylist";
            this.NamePlaylist.HeaderText = "NamePlaylist";
            this.NamePlaylist.MinimumWidth = 6;
            this.NamePlaylist.Name = "NamePlaylist";
            this.NamePlaylist.ReadOnly = true;
            // 
            // IDBaihat
            // 
            this.IDBaihat.DataPropertyName = "IDBaiHat";
            this.IDBaihat.HeaderText = "IDBaihat";
            this.IDBaihat.MinimumWidth = 6;
            this.IDBaihat.Name = "IDBaihat";
            this.IDBaihat.ReadOnly = true;
            this.IDBaihat.Visible = false;
            // 
            // form_list
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(487, 345);
            this.Controls.Add(this.dtgrid);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "form_list";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh sách playlist";
            this.Load += new System.EventHandler(this.form_list_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn NamePlaylist;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDBaihat;
    }
}