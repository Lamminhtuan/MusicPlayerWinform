﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03
{
    public partial class form_list : Form
    {
        public form_list()
        {
            InitializeComponent();
        }

        private void form_list_Load(object sender, EventArgs e)
        {
            dtgrid.DataSource = playlist.data.DefaultView.ToTable(true, "NamePlaylist");
        }

        private void dtgrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            form_playlist form_Playlist = new form_playlist();
            
            string name = dtgrid.SelectedRows[0].Cells["NamePlaylist"].Value.ToString();
            if (name == "Playlist yêu thích" && playlist.CheckYeuThichRong())
                MessageBox.Show("Chưa có bài hát yêu thích nào!");
            else
            {
                form_Playlist.formname = name;
                form_Playlist.ShowDialog();
                dtgrid.DataSource = playlist.data.DefaultView.ToTable(true, "NamePlaylist");
            }

        }
    }
}
