﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03
{
    public partial class form_loading : Form
    {
        public form_loading()
        {
            InitializeComponent();
        }

  

        private void form_loading_Load(object sender, EventArgs e)
        {
            
        }
    }
}
