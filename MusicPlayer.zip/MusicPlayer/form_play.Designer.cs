﻿namespace TH03
{
    partial class form_play
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_play));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ptb_image = new System.Windows.Forms.PictureBox();
            this.lb_name = new System.Windows.Forms.Label();
            this.lb_casi = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pt_hstar5 = new System.Windows.Forms.PictureBox();
            this.pt_fstar5 = new System.Windows.Forms.PictureBox();
            this.pt_hstar4 = new System.Windows.Forms.PictureBox();
            this.pt_fstar4 = new System.Windows.Forms.PictureBox();
            this.pt_hstar2 = new System.Windows.Forms.PictureBox();
            this.btn_share = new System.Windows.Forms.Button();
            this.pt_fstar2 = new System.Windows.Forms.PictureBox();
            this.btn_download = new System.Windows.Forms.Button();
            this.pt_hstar3 = new System.Windows.Forms.PictureBox();
            this.btn_playlist = new System.Windows.Forms.Button();
            this.pt_fstar3 = new System.Windows.Forms.PictureBox();
            this.btn_review = new System.Windows.Forms.Button();
            this.btn_love = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pt_hstar1 = new System.Windows.Forms.PictureBox();
            this.pt_fstar1 = new System.Windows.Forms.PictureBox();
            this.lb_quocgia = new System.Windows.Forms.Label();
            this.lb_tg = new System.Windows.Forms.Label();
            this.lb_luotnghe = new System.Windows.Forms.Label();
            this.lb_theloai = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.rtxt_lyrics = new System.Windows.Forms.RichTextBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dtgrid_cmts = new System.Windows.Forms.DataGridView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btn_lap = new System.Windows.Forms.Button();
            this.axWindowsMediaPlayer1 = new AxWMPLib.AxWindowsMediaPlayer();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_image)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrid_cmts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).BeginInit();
            this.SuspendLayout();
            // 
            // ptb_image
            // 
            this.ptb_image.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ptb_image.Location = new System.Drawing.Point(3, 0);
            this.ptb_image.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ptb_image.Name = "ptb_image";
            this.ptb_image.Size = new System.Drawing.Size(181, 95);
            this.ptb_image.TabIndex = 1;
            this.ptb_image.TabStop = false;
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_name.Location = new System.Drawing.Point(79, 110);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(70, 25);
            this.lb_name.TabIndex = 2;
            this.lb_name.Text = "label1";
            // 
            // lb_casi
            // 
            this.lb_casi.AutoSize = true;
            this.lb_casi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_casi.Location = new System.Drawing.Point(80, 148);
            this.lb_casi.Name = "lb_casi";
            this.lb_casi.Size = new System.Drawing.Size(60, 24);
            this.lb_casi.TabIndex = 3;
            this.lb_casi.Text = "label2";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(23, 142);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(51, 34);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(23, 100);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(51, 34);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(196)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pt_hstar5);
            this.panel1.Controls.Add(this.pt_fstar5);
            this.panel1.Controls.Add(this.pt_hstar4);
            this.panel1.Controls.Add(this.pt_fstar4);
            this.panel1.Controls.Add(this.pt_hstar2);
            this.panel1.Controls.Add(this.btn_share);
            this.panel1.Controls.Add(this.pt_fstar2);
            this.panel1.Controls.Add(this.btn_download);
            this.panel1.Controls.Add(this.pt_hstar3);
            this.panel1.Controls.Add(this.btn_playlist);
            this.panel1.Controls.Add(this.pt_fstar3);
            this.panel1.Controls.Add(this.btn_review);
            this.panel1.Controls.Add(this.btn_love);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pt_hstar1);
            this.panel1.Controls.Add(this.pt_fstar1);
            this.panel1.Controls.Add(this.ptb_image);
            this.panel1.Controls.Add(this.lb_quocgia);
            this.panel1.Controls.Add(this.lb_tg);
            this.panel1.Controls.Add(this.lb_luotnghe);
            this.panel1.Controls.Add(this.lb_theloai);
            this.panel1.Controls.Add(this.lb_casi);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lb_name);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Location = new System.Drawing.Point(-3, -2);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1203, 180);
            this.panel1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1015, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 18);
            this.label1.TabIndex = 6;
            this.label1.Text = "Đánh giá trung bình:";
            // 
            // pt_hstar5
            // 
            this.pt_hstar5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_hstar5.BackgroundImage")));
            this.pt_hstar5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_hstar5.Location = new System.Drawing.Point(1153, 52);
            this.pt_hstar5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pt_hstar5.Name = "pt_hstar5";
            this.pt_hstar5.Size = new System.Drawing.Size(39, 34);
            this.pt_hstar5.TabIndex = 5;
            this.pt_hstar5.TabStop = false;
            this.pt_hstar5.Visible = false;
            // 
            // pt_fstar5
            // 
            this.pt_fstar5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_fstar5.BackgroundImage")));
            this.pt_fstar5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_fstar5.Location = new System.Drawing.Point(1155, 52);
            this.pt_fstar5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pt_fstar5.Name = "pt_fstar5";
            this.pt_fstar5.Size = new System.Drawing.Size(39, 36);
            this.pt_fstar5.TabIndex = 5;
            this.pt_fstar5.TabStop = false;
            this.pt_fstar5.Visible = false;
            // 
            // pt_hstar4
            // 
            this.pt_hstar4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_hstar4.BackgroundImage")));
            this.pt_hstar4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_hstar4.Location = new System.Drawing.Point(1109, 52);
            this.pt_hstar4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pt_hstar4.Name = "pt_hstar4";
            this.pt_hstar4.Size = new System.Drawing.Size(39, 34);
            this.pt_hstar4.TabIndex = 5;
            this.pt_hstar4.TabStop = false;
            this.pt_hstar4.Visible = false;
            // 
            // pt_fstar4
            // 
            this.pt_fstar4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_fstar4.BackgroundImage")));
            this.pt_fstar4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_fstar4.Location = new System.Drawing.Point(1109, 52);
            this.pt_fstar4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pt_fstar4.Name = "pt_fstar4";
            this.pt_fstar4.Size = new System.Drawing.Size(39, 34);
            this.pt_fstar4.TabIndex = 5;
            this.pt_fstar4.TabStop = false;
            this.pt_fstar4.Visible = false;
            // 
            // pt_hstar2
            // 
            this.pt_hstar2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_hstar2.BackgroundImage")));
            this.pt_hstar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_hstar2.Location = new System.Drawing.Point(1020, 50);
            this.pt_hstar2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pt_hstar2.Name = "pt_hstar2";
            this.pt_hstar2.Size = new System.Drawing.Size(39, 34);
            this.pt_hstar2.TabIndex = 5;
            this.pt_hstar2.TabStop = false;
            this.pt_hstar2.Visible = false;
            // 
            // btn_share
            // 
            this.btn_share.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.btn_share.FlatAppearance.BorderSize = 0;
            this.btn_share.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_share.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_share.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_share.Image = ((System.Drawing.Image)(resources.GetObject("btn_share.Image")));
            this.btn_share.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_share.Location = new System.Drawing.Point(1060, 124);
            this.btn_share.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_share.Name = "btn_share";
            this.btn_share.Size = new System.Drawing.Size(132, 46);
            this.btn_share.TabIndex = 6;
            this.btn_share.Text = "Chia sẻ";
            this.btn_share.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_share.UseVisualStyleBackColor = false;
            this.btn_share.Click += new System.EventHandler(this.btn_share_Click);
            // 
            // pt_fstar2
            // 
            this.pt_fstar2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_fstar2.BackgroundImage")));
            this.pt_fstar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_fstar2.Location = new System.Drawing.Point(1020, 50);
            this.pt_fstar2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pt_fstar2.Name = "pt_fstar2";
            this.pt_fstar2.Size = new System.Drawing.Size(39, 34);
            this.pt_fstar2.TabIndex = 5;
            this.pt_fstar2.TabStop = false;
            this.pt_fstar2.Visible = false;
            // 
            // btn_download
            // 
            this.btn_download.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.btn_download.FlatAppearance.BorderSize = 0;
            this.btn_download.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_download.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_download.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_download.Image = ((System.Drawing.Image)(resources.GetObject("btn_download.Image")));
            this.btn_download.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_download.Location = new System.Drawing.Point(923, 124);
            this.btn_download.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_download.Name = "btn_download";
            this.btn_download.Size = new System.Drawing.Size(132, 46);
            this.btn_download.TabIndex = 6;
            this.btn_download.Text = "Tải nhạc";
            this.btn_download.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_download.UseVisualStyleBackColor = false;
            this.btn_download.Click += new System.EventHandler(this.btn_download_Click);
            // 
            // pt_hstar3
            // 
            this.pt_hstar3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_hstar3.BackgroundImage")));
            this.pt_hstar3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_hstar3.Location = new System.Drawing.Point(1065, 52);
            this.pt_hstar3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pt_hstar3.Name = "pt_hstar3";
            this.pt_hstar3.Size = new System.Drawing.Size(39, 34);
            this.pt_hstar3.TabIndex = 5;
            this.pt_hstar3.TabStop = false;
            this.pt_hstar3.Visible = false;
            // 
            // btn_playlist
            // 
            this.btn_playlist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.btn_playlist.FlatAppearance.BorderSize = 0;
            this.btn_playlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_playlist.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_playlist.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_playlist.Image = ((System.Drawing.Image)(resources.GetObject("btn_playlist.Image")));
            this.btn_playlist.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_playlist.Location = new System.Drawing.Point(785, 124);
            this.btn_playlist.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_playlist.Name = "btn_playlist";
            this.btn_playlist.Size = new System.Drawing.Size(132, 46);
            this.btn_playlist.TabIndex = 6;
            this.btn_playlist.Text = "Thêm vào playlist";
            this.btn_playlist.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_playlist.UseVisualStyleBackColor = false;
            this.btn_playlist.Click += new System.EventHandler(this.btn_playlist_Click);
            // 
            // pt_fstar3
            // 
            this.pt_fstar3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_fstar3.BackgroundImage")));
            this.pt_fstar3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_fstar3.Location = new System.Drawing.Point(1065, 52);
            this.pt_fstar3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pt_fstar3.Name = "pt_fstar3";
            this.pt_fstar3.Size = new System.Drawing.Size(39, 34);
            this.pt_fstar3.TabIndex = 5;
            this.pt_fstar3.TabStop = false;
            this.pt_fstar3.Visible = false;
            // 
            // btn_review
            // 
            this.btn_review.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.btn_review.FlatAppearance.BorderSize = 0;
            this.btn_review.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_review.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_review.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_review.Image = ((System.Drawing.Image)(resources.GetObject("btn_review.Image")));
            this.btn_review.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_review.Location = new System.Drawing.Point(511, 124);
            this.btn_review.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_review.Name = "btn_review";
            this.btn_review.Size = new System.Drawing.Size(132, 46);
            this.btn_review.TabIndex = 6;
            this.btn_review.Text = "Đánh giá";
            this.btn_review.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_review.UseVisualStyleBackColor = false;
            this.btn_review.Click += new System.EventHandler(this.btn_review_Click);
            // 
            // btn_love
            // 
            this.btn_love.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.btn_love.FlatAppearance.BorderSize = 0;
            this.btn_love.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_love.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_love.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_love.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_love.Location = new System.Drawing.Point(648, 124);
            this.btn_love.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_love.Name = "btn_love";
            this.btn_love.Size = new System.Drawing.Size(132, 46);
            this.btn_love.TabIndex = 6;
            this.btn_love.Text = "Yêu thích";
            this.btn_love.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_love.UseVisualStyleBackColor = false;
            this.btn_love.Click += new System.EventHandler(this.btn_love_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox3.Location = new System.Drawing.Point(975, 11);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(39, 34);
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // pt_hstar1
            // 
            this.pt_hstar1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_hstar1.BackgroundImage")));
            this.pt_hstar1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_hstar1.Location = new System.Drawing.Point(975, 50);
            this.pt_hstar1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pt_hstar1.Name = "pt_hstar1";
            this.pt_hstar1.Size = new System.Drawing.Size(39, 34);
            this.pt_hstar1.TabIndex = 5;
            this.pt_hstar1.TabStop = false;
            this.pt_hstar1.Visible = false;
            // 
            // pt_fstar1
            // 
            this.pt_fstar1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_fstar1.BackgroundImage")));
            this.pt_fstar1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_fstar1.Location = new System.Drawing.Point(975, 50);
            this.pt_fstar1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pt_fstar1.Name = "pt_fstar1";
            this.pt_fstar1.Size = new System.Drawing.Size(39, 34);
            this.pt_fstar1.TabIndex = 5;
            this.pt_fstar1.TabStop = false;
            this.pt_fstar1.Visible = false;
            // 
            // lb_quocgia
            // 
            this.lb_quocgia.AutoSize = true;
            this.lb_quocgia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_quocgia.Location = new System.Drawing.Point(812, 15);
            this.lb_quocgia.Name = "lb_quocgia";
            this.lb_quocgia.Size = new System.Drawing.Size(60, 24);
            this.lb_quocgia.TabIndex = 3;
            this.lb_quocgia.Text = "label2";
            // 
            // lb_tg
            // 
            this.lb_tg.AutoSize = true;
            this.lb_tg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tg.Location = new System.Drawing.Point(261, 23);
            this.lb_tg.Name = "lb_tg";
            this.lb_tg.Size = new System.Drawing.Size(46, 17);
            this.lb_tg.TabIndex = 3;
            this.lb_tg.Text = "label2";
            // 
            // lb_luotnghe
            // 
            this.lb_luotnghe.AutoSize = true;
            this.lb_luotnghe.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_luotnghe.Location = new System.Drawing.Point(813, 58);
            this.lb_luotnghe.Name = "lb_luotnghe";
            this.lb_luotnghe.Size = new System.Drawing.Size(60, 24);
            this.lb_luotnghe.TabIndex = 3;
            this.lb_luotnghe.Text = "label2";
            // 
            // lb_theloai
            // 
            this.lb_theloai.AutoSize = true;
            this.lb_theloai.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_theloai.Location = new System.Drawing.Point(261, 63);
            this.lb_theloai.Name = "lb_theloai";
            this.lb_theloai.Size = new System.Drawing.Size(60, 24);
            this.lb_theloai.TabIndex = 3;
            this.lb_theloai.Text = "label2";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(756, 9);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(49, 34);
            this.pictureBox6.TabIndex = 4;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(756, 50);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(49, 34);
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.BackgroundImage")));
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox8.Location = new System.Drawing.Point(205, 14);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(51, 34);
            this.pictureBox8.TabIndex = 4;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(205, 55);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(51, 34);
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // rtxt_lyrics
            // 
            this.rtxt_lyrics.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.rtxt_lyrics.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtxt_lyrics.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxt_lyrics.ForeColor = System.Drawing.SystemColors.Window;
            this.rtxt_lyrics.Location = new System.Drawing.Point(12, 449);
            this.rtxt_lyrics.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rtxt_lyrics.Name = "rtxt_lyrics";
            this.rtxt_lyrics.ReadOnly = true;
            this.rtxt_lyrics.Size = new System.Drawing.Size(597, 171);
            this.rtxt_lyrics.TabIndex = 7;
            this.rtxt_lyrics.Text = "";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox7.Location = new System.Drawing.Point(16, 412);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(43, 30);
            this.pictureBox7.TabIndex = 8;
            this.pictureBox7.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(67, 412);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 29);
            this.label2.TabIndex = 9;
            this.label2.Text = "Lời bài hát:";
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox9.BackgroundImage")));
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox9.Location = new System.Drawing.Point(657, 412);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(44, 30);
            this.pictureBox9.TabIndex = 8;
            this.pictureBox9.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(709, 412);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 29);
            this.label3.TabIndex = 9;
            this.label3.Text = "Bình luận:";
            // 
            // dtgrid_cmts
            // 
            this.dtgrid_cmts.AllowUserToAddRows = false;
            this.dtgrid_cmts.AllowUserToDeleteRows = false;
            this.dtgrid_cmts.AllowUserToResizeColumns = false;
            this.dtgrid_cmts.AllowUserToResizeRows = false;
            this.dtgrid_cmts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgrid_cmts.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.dtgrid_cmts.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgrid_cmts.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenHorizontal;
            this.dtgrid_cmts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgrid_cmts.ColumnHeadersVisible = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgrid_cmts.DefaultCellStyle = dataGridViewCellStyle1;
            this.dtgrid_cmts.Location = new System.Drawing.Point(616, 449);
            this.dtgrid_cmts.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtgrid_cmts.Name = "dtgrid_cmts";
            this.dtgrid_cmts.RowHeadersVisible = false;
            this.dtgrid_cmts.RowHeadersWidth = 51;
            this.dtgrid_cmts.RowTemplate.Height = 30;
            this.dtgrid_cmts.Size = new System.Drawing.Size(575, 171);
            this.dtgrid_cmts.TabIndex = 10;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "1329083_appreciate_enabled_feelings_heart_like_icon.png");
            this.imageList1.Images.SetKeyName(1, "1329082_appreciate_disabled_feelings_heart_like_icon.png");
            // 
            // btn_lap
            // 
            this.btn_lap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(193)))));
            this.btn_lap.FlatAppearance.BorderSize = 0;
            this.btn_lap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_lap.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_lap.Image = ((System.Drawing.Image)(resources.GetObject("btn_lap.Image")));
            this.btn_lap.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_lap.Location = new System.Drawing.Point(600, 370);
            this.btn_lap.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_lap.Name = "btn_lap";
            this.btn_lap.Size = new System.Drawing.Size(115, 31);
            this.btn_lap.TabIndex = 30;
            this.btn_lap.Text = "Lặp";
            this.btn_lap.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_lap.UseVisualStyleBackColor = false;
            this.btn_lap.Click += new System.EventHandler(this.btn_lap_Click);
            // 
            // axWindowsMediaPlayer1
            // 
            this.axWindowsMediaPlayer1.Enabled = true;
            this.axWindowsMediaPlayer1.Location = new System.Drawing.Point(0, 140);
            this.axWindowsMediaPlayer1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.axWindowsMediaPlayer1.Name = "axWindowsMediaPlayer1";
            this.axWindowsMediaPlayer1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer1.OcxState")));
            this.axWindowsMediaPlayer1.Size = new System.Drawing.Size(898, 190);
            this.axWindowsMediaPlayer1.TabIndex = 0;
            this.axWindowsMediaPlayer1.Enter += new System.EventHandler(this.axWindowsMediaPlayer1_Enter);
            // 
            // form_play
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1196, 631);
            this.Controls.Add(this.btn_lap);
            this.Controls.Add(this.dtgrid_cmts);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.rtxt_lyrics);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.axWindowsMediaPlayer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.Name = "form_play";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.form_play_FormClosing);
            this.Load += new System.EventHandler(this.form_play_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ptb_image)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrid_cmts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer1;
        private System.Windows.Forms.PictureBox ptb_image;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Label lb_casi;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pt_fstar5;
        private System.Windows.Forms.PictureBox pt_fstar4;
        private System.Windows.Forms.PictureBox pt_fstar2;
        private System.Windows.Forms.PictureBox pt_fstar3;
        private System.Windows.Forms.PictureBox pt_fstar1;
        private System.Windows.Forms.Label lb_tg;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pt_hstar5;
        private System.Windows.Forms.PictureBox pt_hstar4;
        private System.Windows.Forms.PictureBox pt_hstar2;
        private System.Windows.Forms.PictureBox pt_hstar3;
        private System.Windows.Forms.PictureBox pt_hstar1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btn_love;
        private System.Windows.Forms.Label lb_theloai;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.RichTextBox rtxt_lyrics;
        private System.Windows.Forms.Label lb_quocgia;
        private System.Windows.Forms.Label lb_luotnghe;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button btn_download;
        private System.Windows.Forms.Button btn_share;
        private System.Windows.Forms.Button btn_playlist;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dtgrid_cmts;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btn_lap;
        private System.Windows.Forms.Button btn_review;
    }
}