﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03
{
    public partial class form_play : Form
    {
        public int ID { get; set; }
        public string musicpath { get; set; }
        public string tenbaihat { get; set; }
        public string casi { get; set; }
        public string imagepath { get; set; }
        public string tacgia { get; set; }
        public double star { get; set; }
   
        public int luotnghe { get; set; }
        public string loibaihat { get; set; }
        public string theloai { get; set; }
        public string quocgia { get; set; }

        public form_play()
        {
            InitializeComponent();
        }
        
        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {
           
        }

        private void form_play_Load(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.URL = musicpath;
            dtgrid_cmts.DataSource = reviews.GetCmtById(ID);
            if (dtgrid_cmts.Rows.Count > 0)
            {
                dtgrid_cmts.Columns["ID"].Visible = false;
                dtgrid_cmts.Columns["Star"].Visible = false;
            }
            this.Text = tenbaihat + " - " + casi;
            rtxt_lyrics.Text = loibaihat;
            lb_name.Text = tenbaihat;
            lb_casi.Text = casi;
            lb_tg.Text = tacgia;
            lb_luotnghe.Text = luotnghe.ToString();
            lb_quocgia.Text = quocgia;
            lb_theloai.Text = theloai;
            ptb_image.BackgroundImage = Image.FromFile(imagepath);
            if (playlist.CheckBaiHatYeuThich(ID))
            {

                btn_love.Text = "Bỏ\r\nyêu thích";
                btn_love.Image = imageList1.Images[1];
               
            }
            else
            {
                btn_love.Text = "Yêu thích";
                btn_love.Image = imageList1.Images[0];
            }
            double newstar = Math.Round(star * 2, MidpointRounding.AwayFromZero) / 2;
            if (newstar == 0)
            {

            }
            if (newstar == 0.5)
            {
                pt_hstar1.Visible = true;
            }
            if (newstar == 1)
            {
                pt_fstar1.Visible = true;
            }
            if (newstar == 1.5)
            {
                pt_fstar1.Visible = true;
                pt_hstar2.Visible = true;
            }
            if (newstar == 2)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
            }
            if (newstar == 2.5)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_hstar3.Visible = true;
            }
            if (newstar == 3)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
            }
            if (newstar == 3.5)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
                pt_hstar4.Visible = true;
            }
            if (newstar == 4)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
                pt_fstar4.Visible = true;
            }
            if (newstar == 4.5)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
                pt_fstar4.Visible = true;
                pt_hstar5.Visible = true;
            }
            if (newstar == 5)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
                pt_fstar4.Visible = true;
                pt_fstar5.Visible = true;
            }
        }

        private void form_play_FormClosing(object sender, FormClosingEventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.stop();
        }

        private void btn_download_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "|*.mp3";
            sfd.FileName = tenbaihat + ".mp3";
            
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string path = Path.GetFullPath(sfd.FileName);

                File.Copy(musicpath, path);
                MessageBox.Show("Tải nhạc thành công!");
            }
        }

        private void btn_love_Click(object sender, EventArgs e)
        {
            if (btn_love.Text == "Yêu thích")
            {
                btn_love.Text = "Bỏ\r\nyêu thích";
                btn_love.Image = imageList1.Images[1];
                playlist.AddOne("Playlist yêu thích", ID);
                return;
            }
            else if (btn_love.Text == "Bỏ\r\nyêu thích")
            {
                btn_love.Text = "Yêu thích";
                btn_love.Image = imageList1.Images[0];
                playlist.DelOne("Playlist yêu thích", ID);
                return;
            }
        }

        private void btn_lap_Click(object sender, EventArgs e)
        {
            if (btn_lap.Text == "Lặp")
            {
                axWindowsMediaPlayer1.settings.setMode("loop", true);
                btn_lap.Text = "Bỏ lặp";
                btn_lap.BackColor = Color.FromArgb(159, 0, 0);
                return;
            }
            if (btn_lap.Text == "Bỏ lặp")
            {

                axWindowsMediaPlayer1.settings.setMode("loop", false);
                btn_lap.Text = "Lặp";
                btn_lap.BackColor = Color.FromArgb(0, 122, 193);
                return;
            }
        }

        private void btn_share_Click(object sender, EventArgs e)
        {

            System.Diagnostics.Process.Start("http://fb.com");
        }

        private void btn_playlist_Click(object sender, EventArgs e)
        {
            form_add_playlist f = new form_add_playlist();
            f.idbaihat = ID;
            f.ShowDialog();
        }

        private void btn_review_Click(object sender, EventArgs e)
        {
           
            form_review rv = new form_review();
            rv.ID = ID;
            rv.tenbaihat = tenbaihat;
            rv.tacgia = tacgia;
            rv.casi = casi;
            rv.imagepath = imagepath;
            rv.ShowDialog();
            pt_fstar1.Visible = false;
            pt_fstar2.Visible = false;
            pt_fstar3.Visible = false;
            pt_fstar4.Visible = false;
            pt_fstar5.Visible = false;
            pt_hstar1.Visible = false;
            pt_hstar2.Visible = false;
            pt_hstar3.Visible = false;
            pt_hstar4.Visible = false;
            pt_hstar5.Visible = false;
            dtgrid_cmts.DataSource = reviews.GetCmtById(ID);
            if (dtgrid_cmts.Rows.Count > 0)
            {
                dtgrid_cmts.Columns["ID"].Visible = false;
                dtgrid_cmts.Columns["Star"].Visible = false;
            }
            double temp = Convert.ToDouble(songs.GetByID(ID).Rows[0]["Star"].ToString());
            double newstar = Math.Round(temp * 2, MidpointRounding.AwayFromZero) / 2;
            if (newstar == 0)
            {

            }
            if (newstar == 0.5)
            {
                pt_hstar1.Visible = true;
            }
            if (newstar == 1)
            {
                pt_fstar1.Visible = true;
            }
            if (newstar == 1.5)
            {
                pt_fstar1.Visible = true;
                pt_hstar2.Visible = true;
            }
            if (newstar == 2)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
            }
            if (newstar == 2.5)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_hstar3.Visible = true;
            }
            if (newstar == 3)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
            }
            if (newstar == 3.5)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
                pt_hstar4.Visible = true;
            }
            if (newstar == 4)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
                pt_fstar4.Visible = true;
            }
            if (newstar == 4.5)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
                pt_fstar4.Visible = true;
                pt_hstar5.Visible = true;
            }
            if (newstar == 5)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
                pt_fstar4.Visible = true;
                pt_fstar5.Visible = true;
            }
        }
    }
}
