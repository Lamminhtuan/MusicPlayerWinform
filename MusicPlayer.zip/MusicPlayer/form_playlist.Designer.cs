﻿namespace TH03
{
    partial class form_playlist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_playlist));
            this.dtgrid = new System.Windows.Forms.DataGridView();
            this.Hinh = new System.Windows.Forms.DataGridViewImageColumn();
            this.SongName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.singer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Author = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lyrics = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ImagePath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MusicPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Star = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.View = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Kind = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lb_casi = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lb_name = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lb_tg = new System.Windows.Forms.Label();
            this.lb_theloai = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lb_quocgia = new System.Windows.Forms.Label();
            this.lb_luotnghe = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.rtxt_lyrics = new System.Windows.Forms.RichTextBox();
            this.pt_hstar5 = new System.Windows.Forms.PictureBox();
            this.pt_fstar5 = new System.Windows.Forms.PictureBox();
            this.pt_hstar4 = new System.Windows.Forms.PictureBox();
            this.pt_fstar4 = new System.Windows.Forms.PictureBox();
            this.pt_hstar2 = new System.Windows.Forms.PictureBox();
            this.pt_fstar2 = new System.Windows.Forms.PictureBox();
            this.pt_hstar3 = new System.Windows.Forms.PictureBox();
            this.pt_fstar3 = new System.Windows.Forms.PictureBox();
            this.pt_hstar1 = new System.Windows.Forms.PictureBox();
            this.pt_fstar1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_tron = new System.Windows.Forms.Button();
            this.axWindowsMediaPlayer1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_share = new System.Windows.Forms.Button();
            this.btn_download = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).BeginInit();
            this.SuspendLayout();
            // 
            // dtgrid
            // 
            this.dtgrid.AllowUserToAddRows = false;
            this.dtgrid.AllowUserToDeleteRows = false;
            this.dtgrid.AllowUserToOrderColumns = true;
            this.dtgrid.AllowUserToResizeColumns = false;
            this.dtgrid.AllowUserToResizeRows = false;
            this.dtgrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(241)))), ((int)(((byte)(255)))));
            this.dtgrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dtgrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dtgrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgrid.ColumnHeadersVisible = false;
            this.dtgrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Hinh,
            this.SongName,
            this.singer,
            this.Author,
            this.Lyrics,
            this.ImagePath,
            this.MusicPath,
            this.ID,
            this.Star,
            this.View,
            this.Nation,
            this.Kind});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(241)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Magenta;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgrid.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtgrid.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dtgrid.Location = new System.Drawing.Point(704, 41);
            this.dtgrid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtgrid.MultiSelect = false;
            this.dtgrid.Name = "dtgrid";
            this.dtgrid.ReadOnly = true;
            this.dtgrid.RowHeadersVisible = false;
            this.dtgrid.RowHeadersWidth = 51;
            this.dtgrid.RowTemplate.Height = 50;
            this.dtgrid.RowTemplate.ReadOnly = true;
            this.dtgrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgrid.Size = new System.Drawing.Size(367, 441);
            this.dtgrid.TabIndex = 2;
            this.dtgrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgrid_CellContentClick);
            // 
            // Hinh
            // 
            this.Hinh.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Hinh.DataPropertyName = "Hinh";
            this.Hinh.FillWeight = 129.0553F;
            this.Hinh.HeaderText = "Hinh";
            this.Hinh.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.Hinh.MinimumWidth = 6;
            this.Hinh.Name = "Hinh";
            this.Hinh.ReadOnly = true;
            this.Hinh.Width = 6;
            // 
            // SongName
            // 
            this.SongName.DataPropertyName = "SongName";
            this.SongName.HeaderText = "Song Name";
            this.SongName.MinimumWidth = 6;
            this.SongName.Name = "SongName";
            this.SongName.ReadOnly = true;
            // 
            // singer
            // 
            this.singer.DataPropertyName = "Singer";
            this.singer.HeaderText = "Singer";
            this.singer.MinimumWidth = 6;
            this.singer.Name = "singer";
            this.singer.ReadOnly = true;
            // 
            // Author
            // 
            this.Author.DataPropertyName = "Author";
            this.Author.HeaderText = "Column1";
            this.Author.MinimumWidth = 6;
            this.Author.Name = "Author";
            this.Author.ReadOnly = true;
            this.Author.Visible = false;
            // 
            // Lyrics
            // 
            this.Lyrics.DataPropertyName = "Lyrics";
            this.Lyrics.HeaderText = "Column1";
            this.Lyrics.MinimumWidth = 6;
            this.Lyrics.Name = "Lyrics";
            this.Lyrics.ReadOnly = true;
            this.Lyrics.Visible = false;
            // 
            // ImagePath
            // 
            this.ImagePath.DataPropertyName = "ImagePath";
            this.ImagePath.HeaderText = "Column1";
            this.ImagePath.MinimumWidth = 6;
            this.ImagePath.Name = "ImagePath";
            this.ImagePath.ReadOnly = true;
            this.ImagePath.Visible = false;
            // 
            // MusicPath
            // 
            this.MusicPath.DataPropertyName = "MusicPath";
            this.MusicPath.HeaderText = "Column1";
            this.MusicPath.MinimumWidth = 6;
            this.MusicPath.Name = "MusicPath";
            this.MusicPath.ReadOnly = true;
            this.MusicPath.Visible = false;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "Column1";
            this.ID.MinimumWidth = 6;
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            // 
            // Star
            // 
            this.Star.DataPropertyName = "Star";
            this.Star.HeaderText = "Column1";
            this.Star.MinimumWidth = 6;
            this.Star.Name = "Star";
            this.Star.ReadOnly = true;
            this.Star.Visible = false;
            // 
            // View
            // 
            this.View.DataPropertyName = "View";
            this.View.HeaderText = "Column1";
            this.View.MinimumWidth = 6;
            this.View.Name = "View";
            this.View.ReadOnly = true;
            this.View.Visible = false;
            // 
            // Nation
            // 
            this.Nation.DataPropertyName = "Nation";
            this.Nation.HeaderText = "Column1";
            this.Nation.MinimumWidth = 6;
            this.Nation.Name = "Nation";
            this.Nation.ReadOnly = true;
            this.Nation.Visible = false;
            // 
            // Kind
            // 
            this.Kind.DataPropertyName = "Kind";
            this.Kind.HeaderText = "Column1";
            this.Kind.MinimumWidth = 6;
            this.Kind.Name = "Kind";
            this.Kind.ReadOnly = true;
            this.Kind.Visible = false;
            // 
            // lb_casi
            // 
            this.lb_casi.AutoSize = true;
            this.lb_casi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_casi.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lb_casi.Location = new System.Drawing.Point(54, 272);
            this.lb_casi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_casi.Name = "lb_casi";
            this.lb_casi.Size = new System.Drawing.Size(46, 18);
            this.lb_casi.TabIndex = 6;
            this.lb_casi.Text = "label2";
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.BackgroundImage")));
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox8.Location = new System.Drawing.Point(11, 299);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(38, 28);
            this.pictureBox8.TabIndex = 7;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(11, 334);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(38, 28);
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(11, 267);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 28);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_name.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lb_name.Location = new System.Drawing.Point(53, 241);
            this.lb_name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(57, 20);
            this.lb_name.TabIndex = 5;
            this.lb_name.Text = "label1";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(11, 233);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(38, 28);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // lb_tg
            // 
            this.lb_tg.AutoSize = true;
            this.lb_tg.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tg.Location = new System.Drawing.Point(54, 305);
            this.lb_tg.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_tg.Name = "lb_tg";
            this.lb_tg.Size = new System.Drawing.Size(35, 13);
            this.lb_tg.TabIndex = 11;
            this.lb_tg.Text = "label2";
            // 
            // lb_theloai
            // 
            this.lb_theloai.AutoSize = true;
            this.lb_theloai.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_theloai.Location = new System.Drawing.Point(53, 340);
            this.lb_theloai.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_theloai.Name = "lb_theloai";
            this.lb_theloai.Size = new System.Drawing.Size(46, 18);
            this.lb_theloai.TabIndex = 12;
            this.lb_theloai.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 405);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 15);
            this.label1.TabIndex = 28;
            this.label1.Text = "Đánh giá trung bình:";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox3.Location = new System.Drawing.Point(11, 400);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(29, 28);
            this.pictureBox3.TabIndex = 25;
            this.pictureBox3.TabStop = false;
            // 
            // lb_quocgia
            // 
            this.lb_quocgia.AutoSize = true;
            this.lb_quocgia.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_quocgia.Location = new System.Drawing.Point(212, 339);
            this.lb_quocgia.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_quocgia.Name = "lb_quocgia";
            this.lb_quocgia.Size = new System.Drawing.Size(46, 18);
            this.lb_quocgia.TabIndex = 13;
            this.lb_quocgia.Text = "label2";
            // 
            // lb_luotnghe
            // 
            this.lb_luotnghe.AutoSize = true;
            this.lb_luotnghe.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_luotnghe.Location = new System.Drawing.Point(54, 374);
            this.lb_luotnghe.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_luotnghe.Name = "lb_luotnghe";
            this.lb_luotnghe.Size = new System.Drawing.Size(46, 18);
            this.lb_luotnghe.TabIndex = 14;
            this.lb_luotnghe.Text = "label2";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Location = new System.Drawing.Point(170, 334);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(38, 28);
            this.pictureBox6.TabIndex = 15;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(11, 368);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(38, 28);
            this.pictureBox5.TabIndex = 16;
            this.pictureBox5.TabStop = false;
            // 
            // rtxt_lyrics
            // 
            this.rtxt_lyrics.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.rtxt_lyrics.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtxt_lyrics.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxt_lyrics.ForeColor = System.Drawing.SystemColors.Window;
            this.rtxt_lyrics.Location = new System.Drawing.Point(328, 262);
            this.rtxt_lyrics.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.rtxt_lyrics.Name = "rtxt_lyrics";
            this.rtxt_lyrics.Size = new System.Drawing.Size(371, 212);
            this.rtxt_lyrics.TabIndex = 30;
            this.rtxt_lyrics.Text = "";
            // 
            // pt_hstar5
            // 
            this.pt_hstar5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_hstar5.BackgroundImage")));
            this.pt_hstar5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_hstar5.Location = new System.Drawing.Point(145, 433);
            this.pt_hstar5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pt_hstar5.Name = "pt_hstar5";
            this.pt_hstar5.Size = new System.Drawing.Size(29, 28);
            this.pt_hstar5.TabIndex = 33;
            this.pt_hstar5.TabStop = false;
            this.pt_hstar5.Visible = false;
            // 
            // pt_fstar5
            // 
            this.pt_fstar5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_fstar5.BackgroundImage")));
            this.pt_fstar5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_fstar5.Location = new System.Drawing.Point(146, 432);
            this.pt_fstar5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pt_fstar5.Name = "pt_fstar5";
            this.pt_fstar5.Size = new System.Drawing.Size(29, 29);
            this.pt_fstar5.TabIndex = 34;
            this.pt_fstar5.TabStop = false;
            this.pt_fstar5.Visible = false;
            // 
            // pt_hstar4
            // 
            this.pt_hstar4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_hstar4.BackgroundImage")));
            this.pt_hstar4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_hstar4.Location = new System.Drawing.Point(112, 433);
            this.pt_hstar4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pt_hstar4.Name = "pt_hstar4";
            this.pt_hstar4.Size = new System.Drawing.Size(29, 28);
            this.pt_hstar4.TabIndex = 35;
            this.pt_hstar4.TabStop = false;
            this.pt_hstar4.Visible = false;
            // 
            // pt_fstar4
            // 
            this.pt_fstar4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_fstar4.BackgroundImage")));
            this.pt_fstar4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_fstar4.Location = new System.Drawing.Point(112, 432);
            this.pt_fstar4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pt_fstar4.Name = "pt_fstar4";
            this.pt_fstar4.Size = new System.Drawing.Size(29, 28);
            this.pt_fstar4.TabIndex = 36;
            this.pt_fstar4.TabStop = false;
            this.pt_fstar4.Visible = false;
            // 
            // pt_hstar2
            // 
            this.pt_hstar2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_hstar2.BackgroundImage")));
            this.pt_hstar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_hstar2.Location = new System.Drawing.Point(45, 432);
            this.pt_hstar2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pt_hstar2.Name = "pt_hstar2";
            this.pt_hstar2.Size = new System.Drawing.Size(29, 28);
            this.pt_hstar2.TabIndex = 37;
            this.pt_hstar2.TabStop = false;
            this.pt_hstar2.Visible = false;
            // 
            // pt_fstar2
            // 
            this.pt_fstar2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_fstar2.BackgroundImage")));
            this.pt_fstar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_fstar2.Location = new System.Drawing.Point(45, 431);
            this.pt_fstar2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pt_fstar2.Name = "pt_fstar2";
            this.pt_fstar2.Size = new System.Drawing.Size(29, 28);
            this.pt_fstar2.TabIndex = 38;
            this.pt_fstar2.TabStop = false;
            this.pt_fstar2.Visible = false;
            // 
            // pt_hstar3
            // 
            this.pt_hstar3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_hstar3.BackgroundImage")));
            this.pt_hstar3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_hstar3.Location = new System.Drawing.Point(79, 433);
            this.pt_hstar3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pt_hstar3.Name = "pt_hstar3";
            this.pt_hstar3.Size = new System.Drawing.Size(29, 28);
            this.pt_hstar3.TabIndex = 39;
            this.pt_hstar3.TabStop = false;
            this.pt_hstar3.Visible = false;
            // 
            // pt_fstar3
            // 
            this.pt_fstar3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_fstar3.BackgroundImage")));
            this.pt_fstar3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_fstar3.Location = new System.Drawing.Point(79, 432);
            this.pt_fstar3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pt_fstar3.Name = "pt_fstar3";
            this.pt_fstar3.Size = new System.Drawing.Size(29, 28);
            this.pt_fstar3.TabIndex = 40;
            this.pt_fstar3.TabStop = false;
            this.pt_fstar3.Visible = false;
            // 
            // pt_hstar1
            // 
            this.pt_hstar1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_hstar1.BackgroundImage")));
            this.pt_hstar1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_hstar1.Location = new System.Drawing.Point(11, 432);
            this.pt_hstar1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pt_hstar1.Name = "pt_hstar1";
            this.pt_hstar1.Size = new System.Drawing.Size(29, 28);
            this.pt_hstar1.TabIndex = 41;
            this.pt_hstar1.TabStop = false;
            this.pt_hstar1.Visible = false;
            // 
            // pt_fstar1
            // 
            this.pt_fstar1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pt_fstar1.BackgroundImage")));
            this.pt_fstar1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pt_fstar1.Location = new System.Drawing.Point(11, 431);
            this.pt_fstar1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pt_fstar1.Name = "pt_fstar1";
            this.pt_fstar1.Size = new System.Drawing.Size(29, 28);
            this.pt_fstar1.TabIndex = 42;
            this.pt_fstar1.TabStop = false;
            this.pt_fstar1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(366, 233);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 24);
            this.label2.TabIndex = 46;
            this.label2.Text = "Lời bài hát:";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox7.Location = new System.Drawing.Point(328, 233);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(32, 24);
            this.pictureBox7.TabIndex = 45;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox9.BackgroundImage")));
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox9.Location = new System.Drawing.Point(704, 12);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(32, 24);
            this.pictureBox9.TabIndex = 45;
            this.pictureBox9.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(742, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(201, 24);
            this.label3.TabIndex = 46;
            this.label3.Text = "Danh sách bài nhạc:";
            // 
            // btn_tron
            // 
            this.btn_tron.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(193)))));
            this.btn_tron.FlatAppearance.BorderSize = 0;
            this.btn_tron.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_tron.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_tron.Image = ((System.Drawing.Image)(resources.GetObject("btn_tron.Image")));
            this.btn_tron.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_tron.Location = new System.Drawing.Point(215, 197);
            this.btn_tron.Name = "btn_tron";
            this.btn_tron.Size = new System.Drawing.Size(68, 25);
            this.btn_tron.TabIndex = 29;
            this.btn_tron.Text = "Trộn";
            this.btn_tron.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_tron.UseVisualStyleBackColor = false;
            this.btn_tron.Click += new System.EventHandler(this.btn_tron_Click);
            // 
            // axWindowsMediaPlayer1
            // 
            this.axWindowsMediaPlayer1.Enabled = true;
            this.axWindowsMediaPlayer1.Location = new System.Drawing.Point(0, -2);
            this.axWindowsMediaPlayer1.Name = "axWindowsMediaPlayer1";
            this.axWindowsMediaPlayer1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer1.OcxState")));
            this.axWindowsMediaPlayer1.Size = new System.Drawing.Size(699, 229);
            this.axWindowsMediaPlayer1.TabIndex = 0;
            this.axWindowsMediaPlayer1.MediaChange += new AxWMPLib._WMPOCXEvents_MediaChangeEventHandler(this.axWindowsMediaPlayer1_MediaChange);
            this.axWindowsMediaPlayer1.CurrentItemChange += new AxWMPLib._WMPOCXEvents_CurrentItemChangeEventHandler(this.axWindowsMediaPlayer1_CurrentItemChange);
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.btn_add.FlatAppearance.BorderSize = 0;
            this.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_add.Image = ((System.Drawing.Image)(resources.GetObject("btn_add.Image")));
            this.btn_add.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_add.Location = new System.Drawing.Point(288, 190);
            this.btn_add.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(99, 37);
            this.btn_add.TabIndex = 47;
            this.btn_add.Text = "Thêm mới";
            this.btn_add.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.btn_cancel.FlatAppearance.BorderSize = 0;
            this.btn_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_cancel.Image = ((System.Drawing.Image)(resources.GetObject("btn_cancel.Image")));
            this.btn_cancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_cancel.Location = new System.Drawing.Point(391, 190);
            this.btn_cancel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(99, 37);
            this.btn_cancel.TabIndex = 48;
            this.btn_cancel.Text = "Xóa khỏi playlist";
            this.btn_cancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_cancel.UseVisualStyleBackColor = false;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // btn_share
            // 
            this.btn_share.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.btn_share.FlatAppearance.BorderSize = 0;
            this.btn_share.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_share.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_share.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_share.Image = ((System.Drawing.Image)(resources.GetObject("btn_share.Image")));
            this.btn_share.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_share.Location = new System.Drawing.Point(597, 190);
            this.btn_share.Margin = new System.Windows.Forms.Padding(2);
            this.btn_share.Name = "btn_share";
            this.btn_share.Size = new System.Drawing.Size(99, 37);
            this.btn_share.TabIndex = 49;
            this.btn_share.Text = "Chia sẻ";
            this.btn_share.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_share.UseVisualStyleBackColor = false;
            this.btn_share.Click += new System.EventHandler(this.btn_share_Click);
            // 
            // btn_download
            // 
            this.btn_download.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(0)))), ((int)(((byte)(94)))));
            this.btn_download.FlatAppearance.BorderSize = 0;
            this.btn_download.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_download.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_download.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_download.Image = ((System.Drawing.Image)(resources.GetObject("btn_download.Image")));
            this.btn_download.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_download.Location = new System.Drawing.Point(494, 190);
            this.btn_download.Margin = new System.Windows.Forms.Padding(2);
            this.btn_download.Name = "btn_download";
            this.btn_download.Size = new System.Drawing.Size(99, 37);
            this.btn_download.TabIndex = 50;
            this.btn_download.Text = "Tải nhạc";
            this.btn_download.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_download.UseVisualStyleBackColor = false;
            this.btn_download.Click += new System.EventHandler(this.btn_download_Click);
            // 
            // form_playlist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(1075, 485);
            this.Controls.Add(this.btn_share);
            this.Controls.Add(this.btn_download);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pt_hstar5);
            this.Controls.Add(this.pt_fstar5);
            this.Controls.Add(this.pt_hstar4);
            this.Controls.Add(this.pt_fstar4);
            this.Controls.Add(this.pt_hstar2);
            this.Controls.Add(this.pt_fstar2);
            this.Controls.Add(this.pt_hstar3);
            this.Controls.Add(this.pt_fstar3);
            this.Controls.Add(this.pt_hstar1);
            this.Controls.Add(this.pt_fstar1);
            this.Controls.Add(this.rtxt_lyrics);
            this.Controls.Add(this.btn_tron);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.lb_quocgia);
            this.Controls.Add(this.lb_luotnghe);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.lb_tg);
            this.Controls.Add(this.lb_theloai);
            this.Controls.Add(this.lb_casi);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.dtgrid);
            this.Controls.Add(this.axWindowsMediaPlayer1);
            this.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "form_playlist";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form_playlist";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.form_playlist_FormClosing);
            this.Load += new System.EventHandler(this.form_playlist_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_hstar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pt_fstar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer1;
        private System.Windows.Forms.DataGridView dtgrid;
        private System.Windows.Forms.DataGridViewImageColumn Hinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn SongName;
        private System.Windows.Forms.DataGridViewTextBoxColumn singer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Author;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lyrics;
        private System.Windows.Forms.DataGridViewTextBoxColumn ImagePath;
        private System.Windows.Forms.DataGridViewTextBoxColumn MusicPath;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Star;
        private System.Windows.Forms.DataGridViewTextBoxColumn View;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nation;
        private System.Windows.Forms.DataGridViewTextBoxColumn Kind;
        private System.Windows.Forms.Label lb_casi;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lb_tg;
        private System.Windows.Forms.Label lb_theloai;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lb_quocgia;
        private System.Windows.Forms.Label lb_luotnghe;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.RichTextBox rtxt_lyrics;
        private System.Windows.Forms.PictureBox pt_hstar5;
        private System.Windows.Forms.PictureBox pt_fstar5;
        private System.Windows.Forms.PictureBox pt_hstar4;
        private System.Windows.Forms.PictureBox pt_fstar4;
        private System.Windows.Forms.PictureBox pt_hstar2;
        private System.Windows.Forms.PictureBox pt_fstar2;
        private System.Windows.Forms.PictureBox pt_hstar3;
        private System.Windows.Forms.PictureBox pt_fstar3;
        private System.Windows.Forms.PictureBox pt_hstar1;
        private System.Windows.Forms.PictureBox pt_fstar1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_tron;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_share;
        private System.Windows.Forms.Button btn_download;
    }
}