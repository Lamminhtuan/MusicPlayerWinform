﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03
{
    public partial class form_playlist : Form
    {
        int index;
        WMPLib.IWMPMedia temp;
        public string formname { get; set; }
        bool flag = false;
        public form_playlist()
        {
            InitializeComponent();
        }

        private void form_playlist_Load(object sender, EventArgs e)
        {
            this.Text = formname;
            index = 0;
            dtgrid.ForeColor = Color.Black;
            DataTable data = new DataTable();
            data = playlist.GetSongs(formname);
            if (!data.Columns.Contains("Hinh"))
                data.Columns.Add("Hinh", Type.GetType("System.Byte[]"));
            foreach (DataRow dr in data.Rows)
            {
                dr["Hinh"] = File.ReadAllBytes(dr["ImagePath"].ToString());
            }
            dtgrid.DataSource = data;
            axWindowsMediaPlayer1.currentPlaylist = axWindowsMediaPlayer1.newPlaylist("playlist", "");
            List<string> musicpath = new List<string>();
            foreach (DataRow r in data.Rows)
            {
                musicpath.Add(r["MusicPath"].ToString());
            }

            for (int i = 0; i < musicpath.Count; i++)
            {
                axWindowsMediaPlayer1.currentPlaylist.appendItem(axWindowsMediaPlayer1.newMedia(musicpath[i]));
            }
            axWindowsMediaPlayer1.settings.autoStart = true;
            axWindowsMediaPlayer1.Ctlcontrols.play();
            pt_fstar1.Visible = false;
            pt_fstar2.Visible = false;
            pt_fstar3.Visible = false;
            pt_fstar4.Visible = false;
            pt_fstar5.Visible = false;
            pt_hstar1.Visible = false;
            pt_hstar2.Visible = false;
            pt_hstar3.Visible = false;
            pt_hstar4.Visible = false;
            pt_hstar5.Visible = false;
            dtgrid.Rows[index].Selected = true;
            lb_name.Text = dtgrid.Rows[index].Cells["SongName"].Value.ToString();
            rtxt_lyrics.Text = dtgrid.Rows[index].Cells["Lyrics"].Value.ToString();
            lb_casi.Text = dtgrid.Rows[index].Cells["Singer"].Value.ToString();
            lb_name.Text = dtgrid.Rows[index].Cells["SongName"].Value.ToString();
            lb_casi.Text = dtgrid.Rows[index].Cells["Singer"].Value.ToString();
            lb_tg.Text = dtgrid.Rows[index].Cells["Author"].Value.ToString();
            int id = Convert.ToInt32(dtgrid.Rows[index].Cells["ID"].Value.ToString());
            int luotnghe = songs.GetView(id);
            lb_luotnghe.Text = luotnghe.ToString();
            lb_quocgia.Text = dtgrid.Rows[index].Cells["Nation"].Value.ToString();
            lb_theloai.Text = dtgrid.Rows[index].Cells["Kind"].Value.ToString();
            double star = Convert.ToDouble(dtgrid.Rows[index].Cells["Star"].Value.ToString());
            double newstar = Math.Round(star * 2, MidpointRounding.AwayFromZero) / 2;
            if (newstar == 0.5)
            {
                pt_hstar1.Visible = true;
            }
            if (newstar == 1)
            {
                pt_fstar1.Visible = true;
            }
            if (newstar == 1.5)
            {
                pt_fstar1.Visible = true;
                pt_hstar2.Visible = true;
            }
            if (newstar == 2)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
            }
            if (newstar == 2.5)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_hstar3.Visible = true;
            }
            if (newstar == 3)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
            }
            if (newstar == 3.5)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
                pt_hstar4.Visible = true;
            }
            if (newstar == 4)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
                pt_fstar4.Visible = true;
            }
            if (newstar == 4.5)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
                pt_fstar4.Visible = true;
                pt_hstar5.Visible = true;
            }
            if (newstar == 5)
            {
                pt_fstar1.Visible = true;
                pt_fstar2.Visible = true;
                pt_fstar3.Visible = true;
                pt_fstar4.Visible = true;
                pt_fstar5.Visible = true;
            }
            flag = true;


        }
        private void form_playlist_FormClosing(object sender, FormClosingEventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.stop();
        }
        private void dtgrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string musicpath = dtgrid.SelectedRows[0].Cells["MusicPath"].Value.ToString();
            index = dtgrid.CurrentCell.RowIndex;
            WMPLib.IWMPMedia media = axWindowsMediaPlayer1.currentPlaylist.Item[index];
            axWindowsMediaPlayer1.Ctlcontrols.playItem(media);

        }


        private int getindex()
        {
            int index = 0;
            for (int i = 0; i < axWindowsMediaPlayer1.currentPlaylist.count; i++)
            {
                if (axWindowsMediaPlayer1.currentMedia.isIdentical[axWindowsMediaPlayer1.currentPlaylist.Item[i]])
                {
                    index = i;
                    break;
                }
            }
            return index;
        }

        private void axWindowsMediaPlayer1_MediaChange(object sender, AxWMPLib._WMPOCXEvents_MediaChangeEvent e)
        {

        }

        private void btn_tron_Click(object sender, EventArgs e)
        {
            if (btn_tron.Text == "Trộn")
            {
                axWindowsMediaPlayer1.settings.setMode("shuffle", true);
                btn_tron.Text = "Bỏ trộn";
                btn_tron.BackColor = Color.FromArgb(159, 0, 0);
                return;
            }
            if (btn_tron.Text == "Bỏ trộn")
            {
                axWindowsMediaPlayer1.settings.setMode("shuffle", false);
                btn_tron.Text = "Trộn";
                btn_tron.BackColor = Color.FromArgb(0, 122, 193);
                return;
            }

        }
        private void axWindowsMediaPlayer1_CurrentItemChange(object sender, AxWMPLib._WMPOCXEvents_CurrentItemChangeEvent e)
        {
            if (flag == true)
            {
                pt_fstar1.Visible = false;
                pt_fstar2.Visible = false;
                pt_fstar3.Visible = false;
                pt_fstar4.Visible = false;
                pt_fstar5.Visible = false;
                pt_hstar1.Visible = false;
                pt_hstar2.Visible = false;
                pt_hstar3.Visible = false;
                pt_hstar4.Visible = false;
                pt_hstar5.Visible = false;
                dtgrid.Rows[index].Selected = true;
                string tenbaihat = dtgrid.Rows[index].Cells["SongName"].Value.ToString();
                string lyrics = dtgrid.Rows[index].Cells["Lyrics"].Value.ToString();
                string casi = dtgrid.Rows[index].Cells["Singer"].Value.ToString();
                string tacgia = dtgrid.Rows[index].Cells["Author"].Value.ToString();
                string quocgia = dtgrid.Rows[index].Cells["Nation"].Value.ToString();
                string theloai = dtgrid.Rows[index].Cells["Kind"].Value.ToString();
                string imagepath = dtgrid.Rows[index].Cells["ImagePath"].Value.ToString();
                string musicpath = dtgrid.Rows[index].Cells["MusicPath"].Value.ToString();
                lb_name.Text = tenbaihat;
                rtxt_lyrics.Text = lyrics;
                lb_casi.Text = casi;
                lb_tg.Text = tacgia;
                int id = Convert.ToInt32(dtgrid.Rows[index].Cells["ID"].Value.ToString());
                songs.AddOne(id);
                int luotnghe = songs.GetView(id);
                lb_luotnghe.Text = luotnghe.ToString();
                lb_quocgia.Text = quocgia;
                lb_theloai.Text = theloai;
                double star = Convert.ToDouble(dtgrid.Rows[index].Cells["Star"].Value.ToString());
                double newstar = Math.Round(star * 2, MidpointRounding.AwayFromZero) / 2;
                if (newstar == 0.5)
                {
                    pt_hstar1.Visible = true;
                }
                if (newstar == 1)
                {
                    pt_fstar1.Visible = true;
                }
                if (newstar == 1.5)
                {
                    pt_fstar1.Visible = true;
                    pt_hstar2.Visible = true;
                }
                if (newstar == 2)
                {
                    pt_fstar1.Visible = true;
                    pt_fstar2.Visible = true;
                }
                if (newstar == 2.5)
                {
                    pt_fstar1.Visible = true;
                    pt_fstar2.Visible = true;
                    pt_hstar3.Visible = true;
                }
                if (newstar == 3)
                {
                    pt_fstar1.Visible = true;
                    pt_fstar2.Visible = true;
                    pt_fstar3.Visible = true;
                }
                if (newstar == 3.5)
                {
                    pt_fstar1.Visible = true;
                    pt_fstar2.Visible = true;
                    pt_fstar3.Visible = true;
                    pt_hstar4.Visible = true;
                }
                if (newstar == 4)
                {
                    pt_fstar1.Visible = true;
                    pt_fstar2.Visible = true;
                    pt_fstar3.Visible = true;
                    pt_fstar4.Visible = true;
                }
                if (newstar == 4.5)
                {
                    pt_fstar1.Visible = true;
                    pt_fstar2.Visible = true;
                    pt_fstar3.Visible = true;
                    pt_fstar4.Visible = true;
                    pt_hstar5.Visible = true;
                }
                if (newstar == 5)
                {
                    pt_fstar1.Visible = true;
                    pt_fstar2.Visible = true;
                    pt_fstar3.Visible = true;
                    pt_fstar4.Visible = true;
                    pt_fstar5.Visible = true;
                }
                history.Add(id, imagepath, musicpath, tenbaihat, tacgia, casi, quocgia, theloai, luotnghe, lyrics, star, DateTime.Now.ToString());
            }
            flag = true;
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            form_loading load = new form_loading();
            load.Show();
            Application.DoEvents();
            form_songs f = new form_songs();
            f.tenplaylist = formname;
            f.ShowDialog();
            load.Close();

            DataTable data = new DataTable();

            data = playlist.GetSongs(formname);
            if (!data.Columns.Contains("Hinh"))
                data.Columns.Add("Hinh", Type.GetType("System.Byte[]"));
            foreach (DataRow dr in data.Rows)
            {
                dr["Hinh"] = File.ReadAllBytes(dr["ImagePath"].ToString());
            }
            dtgrid.DataSource = data;
            dtgrid.Columns["ID"].Visible = false;
            dtgrid.Columns["MusicPath"].Visible = false;
            dtgrid.Columns["ImagePath"].Visible = false;
            dtgrid.Columns["Author"].Visible = false;
            dtgrid.Columns["Kind"].Visible = false;
            dtgrid.Columns["Nation"].Visible = false;
            dtgrid.Columns["View"].Visible = false;
            dtgrid.Columns["Star"].Visible = false;
            dtgrid.Columns["Lyrics"].Visible = false;

            List<string> musicpath = new List<string>();
            foreach (DataRow r in data.Rows)
            {
                musicpath.Add(r["MusicPath"].ToString());
            }

            for (int i = 0; i < musicpath.Count; i++)
            {
                axWindowsMediaPlayer1.currentPlaylist.appendItem(axWindowsMediaPlayer1.newMedia(musicpath[i]));
            }

            dtgrid.Rows[index].Selected = true;

        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            if (dtgrid.Rows.Count > 0)
            {
                int idbaihat = Convert.ToInt32(dtgrid.Rows[index].Cells["ID"].Value.ToString());
               
                playlist.DelOne(formname, idbaihat);
                DataTable data = new DataTable();

                data = playlist.GetSongs(formname);
                if (!data.Columns.Contains("Hinh"))
                    data.Columns.Add("Hinh", Type.GetType("System.Byte[]"));
                foreach (DataRow dr in data.Rows)
                {
                    dr["Hinh"] = File.ReadAllBytes(dr["ImagePath"].ToString());
                }
                dtgrid.DataSource = data;

                flag = false;
                axWindowsMediaPlayer1.currentPlaylist.removeItem(axWindowsMediaPlayer1.currentMedia);
                axWindowsMediaPlayer1.Ctlcontrols.play();
            }
            else
                MessageBox.Show("Không còn bài hát nào để xóa!");
        }

        private void btn_download_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            string tenbaihat = dtgrid.Rows[index].Cells["SongName"].Value.ToString();
            sfd.Filter = "|*.mp3";
            sfd.FileName = tenbaihat + ".mp3";
          
            string musicpath = dtgrid.Rows[index].Cells["MusicPath"].Value.ToString();
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string path = Path.GetFullPath(sfd.FileName);

                File.Copy(musicpath, path);
                MessageBox.Show("Tải nhạc thành công!");
            }
        }

        private void btn_share_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://fb.com");
        }
    }
}
