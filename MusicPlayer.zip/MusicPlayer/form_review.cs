﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03
{
    public partial class form_review : Form
    {
        private int star;
        bool flag = false;
        public int ID { get; set; }
        public string imagepath { get; set; }
        public string tenbaihat { get; set; }
        public string casi { get; set; }
        public string tacgia { get; set; }
        public form_review()
        {
            InitializeComponent();
        }

        private void form_review_Load(object sender, EventArgs e)
        {
            
            ptb_image.BackgroundImage = Image.FromFile(imagepath);
            lb_name.Text = tenbaihat;
            lb_casi.Text = casi;
            lb_tg.Text = tacgia;
            this.Text = tenbaihat + " - " + casi;
        }

        
        private void btn_1_MouseEnter(object sender, EventArgs e)
        {
            if (!flag)
            btn_1.BackgroundImage = imageList1.Images[1];
        }

        private void btn_1_MouseLeave(object sender, EventArgs e)
        {
            if(!flag)
            btn_1.BackgroundImage = imageList1.Images[0];

        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            star = 1;
            btn_1.BackgroundImage = imageList1.Images[1];
            flag = true;
        }

        private void btn_2_MouseEnter(object sender, EventArgs e)
        {
            if (!flag)
            {
                btn_1.BackgroundImage = imageList1.Images[1];
                btn_2.BackgroundImage = imageList1.Images[1];
            }
        }
        private void btn_2_MouseLeave(object sender, EventArgs e)
        {
            if (!flag)
            {
                btn_1.BackgroundImage = imageList1.Images[0];
                btn_2.BackgroundImage = imageList1.Images[0];
            }
        }

        private void btn_2_Click(object sender, EventArgs e)
        {
            star = 2;
            btn_1.BackgroundImage = imageList1.Images[1];
            btn_2.BackgroundImage = imageList1.Images[1];
            flag = true;
        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            star = 3;
            btn_1.BackgroundImage = imageList1.Images[1];
            btn_2.BackgroundImage = imageList1.Images[1];
            btn_3.BackgroundImage = imageList1.Images[1];
            flag = true;
        }

        private void btn_3_MouseEnter(object sender, EventArgs e)
        {
            if (!flag)
            {
                btn_1.BackgroundImage = imageList1.Images[1];
                btn_2.BackgroundImage = imageList1.Images[1];
                btn_3.BackgroundImage = imageList1.Images[1];
            }
        }

        private void btn_3_MouseLeave(object sender, EventArgs e)
        {
            if (!flag)
            {
                btn_1.BackgroundImage = imageList1.Images[0];
                btn_2.BackgroundImage = imageList1.Images[0];
                btn_3.BackgroundImage = imageList1.Images[0];
            }
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            star = 4;
            btn_1.BackgroundImage = imageList1.Images[1];
            btn_2.BackgroundImage = imageList1.Images[1];
            btn_3.BackgroundImage = imageList1.Images[1];
            btn_4.BackgroundImage = imageList1.Images[1];
            flag = true;
        }

        private void btn_4_MouseEnter(object sender, EventArgs e)
        {
            if (!flag)
            {
                btn_1.BackgroundImage = imageList1.Images[1];
                btn_2.BackgroundImage = imageList1.Images[1];
                btn_3.BackgroundImage = imageList1.Images[1];
                btn_4.BackgroundImage = imageList1.Images[1];
            }
        }

        private void btn_4_MouseLeave(object sender, EventArgs e)
        {
            if (!flag)
            {
                btn_1.BackgroundImage = imageList1.Images[0];
                btn_2.BackgroundImage = imageList1.Images[0];
                btn_3.BackgroundImage = imageList1.Images[0];
                btn_4.BackgroundImage = imageList1.Images[0];
            }
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            star = 5;
            btn_1.BackgroundImage = imageList1.Images[1];
            btn_2.BackgroundImage = imageList1.Images[1];
            btn_3.BackgroundImage = imageList1.Images[1];
            btn_4.BackgroundImage = imageList1.Images[1];
            btn_5.BackgroundImage = imageList1.Images[1];
            flag = true;
        }

        private void btn_5_MouseEnter(object sender, EventArgs e)
        {
            if (!flag)
            {
                btn_1.BackgroundImage = imageList1.Images[1];
                btn_2.BackgroundImage = imageList1.Images[1];
                btn_3.BackgroundImage = imageList1.Images[1];
                btn_4.BackgroundImage = imageList1.Images[1];
                btn_5.BackgroundImage = imageList1.Images[1];
            }
        }

        private void btn_5_MouseLeave(object sender, EventArgs e)
        {
            if (!flag)
            {
                btn_1.BackgroundImage = imageList1.Images[0];
                btn_2.BackgroundImage = imageList1.Images[0];
                btn_3.BackgroundImage = imageList1.Images[0];
                btn_4.BackgroundImage = imageList1.Images[0];
                btn_5.BackgroundImage = imageList1.Images[0];
            }
        }

        private void btn_review_Click(object sender, EventArgs e)
        {
            string cmt = rtxt_cmt.Text;
            reviews.AddOne(ID, star, cmt);
            this.Close();
        }
    }
}

