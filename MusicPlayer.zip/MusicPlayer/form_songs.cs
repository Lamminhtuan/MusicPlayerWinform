﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03
{
    public partial class form_songs : Form
    {
        public string tenplaylist { get; set; }

        public form_songs()
        {
            InitializeComponent();
        }

        private void form_history_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = songs.data;
            if (!dt.Columns.Contains("Hinh"))
                dt.Columns.Add("Hinh", Type.GetType("System.Byte[]"));
            
            foreach (DataRow dr in dt.Rows)
            {
                dr["Hinh"] = File.ReadAllBytes(dr["ImagePath"].ToString());
            }
            dtgrid.DataSource = dt;
        }

        private void dtgrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int idbaihat = Convert.ToInt32(dtgrid.SelectedRows[0].Cells["ID"].Value.ToString());
            if (!playlist.CheckTrungPlaylist(tenplaylist, idbaihat))
            {
                playlist.AddOne(tenplaylist, idbaihat);
                MessageBox.Show("Thêm thành công vào " + tenplaylist);
            }
            else
                MessageBox.Show("Playlist đã tồn tại bài hát!");    
        }
    }
}
