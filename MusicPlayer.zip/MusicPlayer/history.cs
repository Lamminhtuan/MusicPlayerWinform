﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace TH03
{
    internal class history
    {
        public static DataTable data { get; set; }
        public static void KhoiTao()
        {
            data = new DataTable();
            data.Columns.Add("ID");
            data.Columns.Add("ImagePath", typeof(string));
            data.Columns.Add("MusicPath", typeof(string));
            data.Columns.Add("SongName", typeof(string));
            data.Columns.Add("Author", typeof(string));
            data.Columns.Add("Singer", typeof(string));
            data.Columns.Add("Nation", typeof(string));
            data.Columns.Add("Kind", typeof(string));
            data.Columns.Add("View", typeof(int));
            data.Columns.Add("Lyrics", typeof(string));
            data.Columns.Add("Star", typeof(double));
            data.Columns.Add("Time", typeof(string));
        }
        public static void Add(int id, string imagepath, string musicpath, string song, string author, string singer, string nation, string kind, int view, string lyrics, double star, string time)
        {
            data.Rows.Add(id, imagepath, musicpath, song, author, singer, nation, kind, view, lyrics, star, time);
        }
    }
}
