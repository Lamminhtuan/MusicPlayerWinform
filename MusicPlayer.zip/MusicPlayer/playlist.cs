﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH03
{
    internal class playlist
    {
        public static DataTable data { get; set; }
        public static void KhoiTao()
        {
            data = new DataTable();
            data.Columns.Add("NamePlaylist", typeof(string));
            data.Columns.Add("IDBaiHat", typeof(int));
            data.Rows.Add("Playlist yêu thích", -1);
            data.Rows.Add("Playlist cho tôi", 1);
            data.Rows.Add("Playlist cho tôi", 14);
            data.Rows.Add("Playlist cho tôi", 20);
            data.Rows.Add("Playlist cho tôi", 24);
            data.Rows.Add("Playlist cho tôi 1", 15);
            data.Rows.Add("Playlist cho tôi 1", 16);
        }
        public static bool CheckYeuThichRong()
        {
            string query = String.Format("NamePlaylist = 'Playlist yêu thích'");
            DataRow[] result = data.Select(query);
            if (result.Length == 1)
                return true;
            return false;
        }
      
        public static bool CheckBaiHatYeuThich(int idbaihat)
        {
            string query = String.Format("NamePlaylist = 'Playlist yêu thích' AND IDBaiHat = {0}", idbaihat);
            DataRow[] result = data.Select(query);
            if (result.Length > 0)
                return true;
            return false;
        }
        
        public static bool CheckTrungPlaylist(string tenplaylist, int idbaihat)
        {
            string query = String.Format("NamePlaylist = '{0}' AND IDBaiHat = {1}", tenplaylist, idbaihat);
            DataRow[] result = data.Select(query);
            if (result.Length > 0)
                return true;
            return false;
        }
        public static bool CheckTrung(string tenplaylist)
        {
            string query = String.Format("NamePlaylist = '{0}'", tenplaylist);
            DataRow[] result = data.Select(query);
            if (result.Length > 0)
                return true;
            return false;
        }
        
        public static void AddOne(string name, int idbaihat)
        {
            data.Rows.Add(name, idbaihat);
        }
        public static void DelOne(string name, int idbaihat)
        {
            string query = String.Format("NamePlaylist = '{0}' AND IDBaiHat = {1}", name, idbaihat);
            DataRow[] result = data.Select(query);
            if (result.Length > 0)
            {
                result[0].Delete();
            }
            data.AcceptChanges();
        }
        public static DataTable GetSongs(string tenplaylist)
        {
            string query = String.Format("NamePlaylist = '{0}'", tenplaylist);
            DataRow[] result = data.Select(query);
            List<int> id = new List<int>();
            if (result.Length > 0)
            {
                for (int i = 0; i < result.Length; i++)
                {
                    id.Add(Convert.ToInt32(result[i]["IDBaiHat"].ToString()));
                }
            }
            return songs.GetByPlaylist(id);
        }
    }
}
