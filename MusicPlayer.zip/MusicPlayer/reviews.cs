﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH03
{
    internal class reviews
    {
        public static DataTable data { get; set; }
        public static void KhoiTao()
        {
            data = new DataTable();
            data.Columns.Add("ID", typeof(int));
            data.Columns.Add("Star", typeof(int));
            data.Columns.Add("Binhluan", typeof(string));
            data.Rows.Add(0, 5, "Nhạc hay!");
            data.Rows.Add(0, 5, "Nhạc hay quá!");
            data.Rows.Add(0, 4, "Nhạc tạm được!");
        }
        public static void AddOne(int id, int star, string cmt)
        {
            data.Rows.Add(id, star, cmt);
            songs.UpdateStar(id, CalcStar(id));

        }
        public static double CalcStar(int id)
        {
            long sum = 0;
            long number = 0;
            string query = String.Format("ID = {0}", id);
            DataRow[] result = data.Select(query);
            number = result.Length;
            for (int i = 0; i < result.Length; i++)
            {
                sum += Convert.ToInt32(result[i]["Star"].ToString());

            }


            return (double)sum / number;
        }
        public static DataTable GetCmtById(int id)
        {
            DataTable dt = new DataTable();
            string query = String.Format("ID = {0}", id);
            DataRow[] result = data.Select(query);
            if (result.Length > 0)
            {
                dt = result.CopyToDataTable();
            }
            return dt;
        }
    }
}
