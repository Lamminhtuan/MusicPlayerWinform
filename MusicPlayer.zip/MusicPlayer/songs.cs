﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;
using System.Windows.Forms;
using System.IO;

namespace TH03
{
    internal class songs
    {
        public static DataTable data { get; set; }
        public static void KhoiTao()
        {
            data = new DataTable();
            data.Columns.Add("ID", typeof(int));
            data.Columns.Add("ImagePath", typeof(string));
            data.Columns.Add("MusicPath", typeof(string));
            data.Columns.Add("SongName", typeof(string));
            data.Columns.Add("Author", typeof(string));
            data.Columns.Add("Singer", typeof(string));
            data.Columns.Add("Nation", typeof(string));
            data.Columns.Add("Kind", typeof(string));
            data.Columns.Add("View", typeof(int));
            data.Columns.Add("Lyrics", typeof(string));
            data.Columns.Add("Star", typeof(double));
            string slnpath = Path.GetFullPath(Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "..\\..\\"));
            
            data.Rows.Add(0, "..\\..\\images\\0.png", slnpath + "songs\\Cartoon On On feat Daniel Levi NCS Release.mp3", "On & On", "Cartoon (feat. Daniel Levi)", "Cartoon (feat. Daniel Levi)", "Âu Mỹ", "EDM", 0, @"Music provided by NoCopyrightSounds.
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut eget nibh id nisl dignissim ornare. In mollis lacus ipsum, suscipit ornare lectus vestibulum sed. Nam eleifend varius tortor, nec ultrices dui congue quis. Nullam sapien ipsum, malesuada sodales malesuada quis, tristique sit amet ex. Nunc condimentum placerat ultricies. Morbi quis purus rutrum, porta tortor non, vehicula urna. Etiam id placerat odio. Etiam bibendum erat id arcu aliquet, sed pellentesque neque eleifend. Nunc iaculis est orci, sed aliquet elit luctus nec. Proin quis quam sit amet lacus sagittis convallis. 
", 0);
            data.Rows.Add(1, "..\\..\\images\\1.png", slnpath + "songs\\Lost Sky Fearless ptII feat Chris Linton NCS Release.mp3", "Fearless pt.II", "Lost Sky (feat. Chris Linton)", "Lost Sky (feat. Chris Linton)", "Âu Mỹ", "EDM", 0, "Music provided by NoCopyrightSounds." +
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut eget nibh id nisl dignissim ornare. In mollis lacus ipsum, suscipit ornare lectus vestibulum sed. Nam eleifend varius tortor, nec ultrices dui congue quis. Nullam sapien ipsum, malesuada sodales malesuada quis, tristique sit amet ex. Nunc condimentum placerat ultricies. Morbi quis purus rutrum, porta tortor non, vehicula urna. Etiam id placerat odio. Etiam bibendum erat id arcu aliquet, sed pellentesque neque eleifend. Nunc iaculis est orci, sed aliquet elit luctus nec. Proin quis quam sit amet lacus sagittis convallis. ", 0);
            data.Rows.Add(2, "..\\..\\images\\2.png", slnpath + "songs\\Warriyo Mortals feat Laura Brehm NCS Release.mp3", "Mortals", "Warriyo (feat. Laura Brehm)", "Warriyo (feat. Laura Brehm)", "Âu Mỹ", "EDM", 0, "Music provided by NoCopyrightSounds." +
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut eget nibh id nisl dignissim ornare. In mollis lacus ipsum, suscipit ornare lectus vestibulum sed. Nam eleifend varius tortor, nec ultrices dui congue quis. Nullam sapien ipsum, malesuada sodales malesuada quis, tristique sit amet ex. Nunc condimentum placerat ultricies. Morbi quis purus rutrum, porta tortor non, vehicula urna. Etiam id placerat odio. Etiam bibendum erat id arcu aliquet, sed pellentesque neque eleifend. Nunc iaculis est orci, sed aliquet elit luctus nec. Proin quis quam sit amet lacus sagittis convallis. ", 0);
        }
        public static DataTable Search(string name)
        {
            DataTable dt = new DataTable();
            string query = String.Format("SongName LIKE '%{0}%'", name);
            DataRow[] result = data.Select(query);
            if (result.Length > 0)
            {
                dt = result.CopyToDataTable();
            }
            return dt;
        }
        public static void UpdateStar(int id, double star)
        {
            string query = String.Format("ID = {0}", id);
            DataRow[] result = data.Select(query);
            result[0]["Star"] = star;
        }
        public static DataTable Filter(string theloai, string quocgia, string casi, string tacgia)
        {
            DataTable dt = new DataTable();
            string query = String.Format("Kind LIKE '%{0}%' AND Nation LIKE '%{1}%' AND Singer LIKE '%{2}%' AND Author LIKE '%{3}%'", theloai, quocgia, casi, tacgia);
            DataRow[] result = data.Select(query);
            if (result.Length > 0)
            {
                dt = result.CopyToDataTable();
            }
            return dt;
        }
   
        public static void AddOne(int id)
        {
            string query = String.Format("ID = {0}", id);
            DataRow[] result = data.Select(query);
            int now = Convert.ToInt32(result[0]["View"]);
            now = now + 1;
            result[0]["View"] = now;
           
        
        }
        public static int GetView(int id)
        {
            string query = String.Format("ID = {0}", id);
            DataRow[] result = data.Select(query);
            return Convert.ToInt32(result[0]["View"].ToString());
        }
        public static DataTable GetByID(int id)
        {
            DataTable dt = new DataTable();
            string query = String.Format("ID = {0}", id);
            DataRow[] result = data.Select(query);
            if (result.Length > 0)
            {
                dt = result.CopyToDataTable();
            }
            return dt;
        }
        public static DataTable GetByPlaylist(List<int> id)
        {
            DataTable dt = new DataTable();
            for (int i = 0; i < id.Count; i++)
                dt.Merge(GetByID(id[i]));
            return dt;
                
        }

    }
}

